import { spawn } from 'child_process';
import path from 'path';
import fs from 'fs/promises';

interface ComponentDefinition {
  id: string;
  type: string;
  subType?: string;
  description: string;
  commonUse?: string;
  pinout?: string;
  testProcedure?: string;
  userDefined: boolean;
  verified: boolean;
  createdAt: string;
  sources: string[];
}

export class DatabaseService {
  private dbPath: string;
  private componentsCollection: ComponentDefinition[] = [];

  constructor() {
    this.dbPath = path.join(process.cwd(), 'database', 'components.json');
    this.initializeDatabase();
  }

  private async initializeDatabase() {
    try {
      // Create database directory
      await fs.mkdir(path.dirname(this.dbPath), { recursive: true });
      
      // Load existing data
      try {
        const data = await fs.readFile(this.dbPath, 'utf-8');
        this.componentsCollection = JSON.parse(data);
        console.log(`✓ Loaded ${this.componentsCollection.length} components from database`);
      } catch {
        // Initialize with empty collection if file doesn't exist
        this.componentsCollection = [];
        await this.saveDatabase();
        console.log('✓ Initialized new component database');
      }
    } catch (error) {
      console.error('Database initialization failed:', error);
    }
  }

  private async saveDatabase(): Promise<void> {
    try {
      await fs.writeFile(this.dbPath, JSON.stringify(this.componentsCollection, null, 2));
    } catch (error) {
      console.error('Failed to save database:', error);
    }
  }

  async addComponent(componentData: Partial<ComponentDefinition>): Promise<ComponentDefinition> {
    const component: ComponentDefinition = {
      id: componentData.id || `comp_${Date.now()}`,
      type: componentData.type || 'unknown',
      subType: componentData.subType,
      description: componentData.description || '',
      commonUse: componentData.commonUse,
      pinout: componentData.pinout,
      testProcedure: componentData.testProcedure,
      userDefined: true,
      verified: true,
      createdAt: new Date().toISOString(),
      sources: componentData.sources || ['User Defined']
    };

    // Remove existing component with same ID if it exists
    this.componentsCollection = this.componentsCollection.filter(c => c.id !== component.id);
    
    // Add new component
    this.componentsCollection.push(component);
    
    // Save to persistent storage
    await this.saveDatabase();
    
    console.log(`✓ Added component ${component.id} to database`);
    return component;
  }

  async removeComponent(componentId: string): Promise<boolean> {
    const initialLength = this.componentsCollection.length;
    this.componentsCollection = this.componentsCollection.filter(c => c.id !== componentId);
    
    if (this.componentsCollection.length < initialLength) {
      await this.saveDatabase();
      console.log(`✓ Removed component ${componentId} from database`);
      return true;
    }
    
    return false;
  }

  async getComponent(componentId: string): Promise<ComponentDefinition | null> {
    return this.componentsCollection.find(c => c.id === componentId) || null;
  }

  async getAllComponents(): Promise<ComponentDefinition[]> {
    return [...this.componentsCollection];
  }

  async searchComponents(query: string): Promise<ComponentDefinition[]> {
    const searchTerm = query.toLowerCase();
    return this.componentsCollection.filter(c => 
      c.id.toLowerCase().includes(searchTerm) ||
      c.type.toLowerCase().includes(searchTerm) ||
      c.description.toLowerCase().includes(searchTerm) ||
      (c.subType && c.subType.toLowerCase().includes(searchTerm))
    );
  }

  async updateComponent(componentId: string, updates: Partial<ComponentDefinition>): Promise<ComponentDefinition | null> {
    const index = this.componentsCollection.findIndex(c => c.id === componentId);
    if (index === -1) return null;

    // Update the component
    this.componentsCollection[index] = {
      ...this.componentsCollection[index],
      ...updates,
      id: componentId // Preserve original ID
    };

    await this.saveDatabase();
    console.log(`✓ Updated component ${componentId}`);
    return this.componentsCollection[index];
  }

  // Auto-backup functionality
  async createBackup(): Promise<string> {
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const backupPath = path.join(path.dirname(this.dbPath), `backup_${timestamp}.json`);
    
    try {
      await fs.copyFile(this.dbPath, backupPath);
      console.log(`✓ Database backup created: ${backupPath}`);
      return backupPath;
    } catch (error) {
      console.error('Backup creation failed:', error);
      throw error;
    }
  }

  // Import/export functionality for migration
  async exportComponents(): Promise<ComponentDefinition[]> {
    return [...this.componentsCollection];
  }

  async importComponents(components: ComponentDefinition[], merge: boolean = true): Promise<number> {
    if (!merge) {
      this.componentsCollection = components;
    } else {
      // Merge components, updating existing ones
      for (const newComponent of components) {
        const existingIndex = this.componentsCollection.findIndex(c => c.id === newComponent.id);
        if (existingIndex >= 0) {
          this.componentsCollection[existingIndex] = newComponent;
        } else {
          this.componentsCollection.push(newComponent);
        }
      }
    }

    await this.saveDatabase();
    console.log(`✓ Imported ${components.length} components`);
    return components.length;
  }

  // Statistics
  async getStats(): Promise<{
    totalComponents: number;
    userDefined: number;
    verified: number;
    byType: Record<string, number>;
  }> {
    const stats = {
      totalComponents: this.componentsCollection.length,
      userDefined: this.componentsCollection.filter(c => c.userDefined).length,
      verified: this.componentsCollection.filter(c => c.verified).length,
      byType: {} as Record<string, number>
    };

    // Count by type
    for (const component of this.componentsCollection) {
      stats.byType[component.type] = (stats.byType[component.type] || 0) + 1;
    }

    return stats;
  }
}

export const databaseService = new DatabaseService();