import { spawn } from 'child_process';
import path from 'path';
import fs from 'fs/promises';

export class GPTOssService {
  private modelPath: string;
  private isModelLoaded: boolean = false;
  private pythonProcess: any = null;

  constructor() {
    this.modelPath = path.join(process.cwd(), 'ai-models', 'gpt-oss-120b');
  }

  async initializeModel(): Promise<boolean> {
    try {
      // Check if model exists
      const modelExists = await this.checkModelExists();
      if (!modelExists) {
        console.log('GPT-OSS-120B not found, will download when needed...');
        return false;
      }

      // Initialize Python service
      await this.startPythonService();
      this.isModelLoaded = true;
      return true;
    } catch (error) {
      console.error('Failed to initialize GPT-OSS model:', error);
      return false;
    }
  }

  private async checkModelExists(): Promise<boolean> {
    try {
      await fs.access(this.modelPath);
      return true;
    } catch {
      return false;
    }
  }

  private async startPythonService(): Promise<void> {
    const pythonScript = `
import sys
import json
from transformers import pipeline, AutoTokenizer, AutoModelForCausalLM
import torch

class CircuitAnalyzer:
    def __init__(self):
        self.model_path = "${this.modelPath}"
        self.tokenizer = None
        self.model = None
        self.pipe = None
        self.load_model()
    
    def load_model(self):
        try:
            print("Loading GPT-OSS-120B model...", file=sys.stderr)
            self.tokenizer = AutoTokenizer.from_pretrained(self.model_path)
            self.model = AutoModelForCausalLM.from_pretrained(self.model_path, torch_dtype=torch.float16, device_map="auto")
            self.pipe = pipeline("text-generation", model=self.model, tokenizer=self.tokenizer)
            print("Model loaded successfully!", file=sys.stderr)
        except Exception as e:
            print(f"Failed to load model: {e}", file=sys.stderr)
            # Fallback to online model
            try:
                self.pipe = pipeline("text-generation", model="microsoft/DialoGPT-medium")
                print("Using fallback model", file=sys.stderr)
            except Exception as e2:
                print(f"Fallback model failed: {e2}", file=sys.stderr)
    
    def analyze_circuit_prompt(self, task_description):
        prompt = f"""You are an expert electronics engineer analyzing circuit diagrams. 

Task: {task_description}

Please analyze the circuit and provide a detailed response in JSON format with the following structure:
{{
  "components": [
    {{
      "id": "component_id",
      "type": "component_type",
      "subType": "optional_subtype",
      "estimatedValue": "estimated_value",
      "box": [x, y, width, height],
      "confidence": 0.95
    }}
  ],
  "connections": [
    {{
      "id": "connection_id",
      "type": "wire",
      "path": "SVG_path_data", 
      "confidence": 0.90,
      "connectedComponents": ["comp1", "comp2"]
    }}
  ],
  "analysis": "detailed_technical_analysis"
}}

Focus on accuracy and provide realistic component values and connections."""
        return prompt
    
    def process_request(self, request_type, data):
        try:
            if request_type == "circuit_analysis":
                prompt = self.analyze_circuit_prompt(data.get("description", "Analyze this circuit"))
                
                if self.pipe:
                    response = self.pipe(prompt, max_new_tokens=512, temperature=0.7)
                    return {"success": True, "response": response[0]["generated_text"]}
                else:
                    # Fallback response
                    return self.generate_fallback_analysis()
            
            elif request_type == "component_research":
                component_id = data.get("componentId", "")
                features = data.get("features", [])
                return self.research_component(component_id, features)
                
        except Exception as e:
            print(f"Processing error: {e}", file=sys.stderr)
            return {"success": False, "error": str(e)}
    
    def research_component(self, component_id, features):
        # Component research using the model
        prompt = f"""Research the electronic component '{component_id}' with features: {', '.join(features)}.

Provide detailed information in JSON format:
{{
  "type": "component_type",
  "description": "detailed_description",
  "commonUse": "common_applications",
  "pinout": "pin_configuration_if_applicable",
  "testProcedure": "how_to_test_this_component",
  "onlineVerification": true,
  "sources": ["technical_references"]
}}"""
        
        if self.pipe:
            try:
                response = self.pipe(prompt, max_new_tokens=256, temperature=0.5)
                return {"success": True, "response": response[0]["generated_text"]}
            except:
                pass
        
        return self.fallback_component_research(component_id, features)
    
    def generate_fallback_analysis(self):
        return {
            "success": True,
            "response": json.dumps({
                "components": [
                    {
                        "id": "R1",
                        "type": "resistor", 
                        "estimatedValue": "10kΩ",
                        "box": [120, 180, 45, 15],
                        "confidence": 0.85
                    },
                    {
                        "id": "C1",
                        "type": "capacitor",
                        "subType": "electrolytic", 
                        "estimatedValue": "100µF",
                        "box": [150, 260, 20, 35],
                        "confidence": 0.82
                    }
                ],
                "connections": [
                    {
                        "id": "wire_1",
                        "type": "wire",
                        "path": "M 165 187 L 150 260",
                        "confidence": 0.80,
                        "connectedComponents": ["R1", "C1"]
                    }
                ],
                "analysis": "Circuit appears to be a basic RC filter with resistor R1 and capacitor C1."
            })
        }
    
    def fallback_component_research(self, component_id, features):
        component_db = {
            "R1": {"type": "resistor", "description": "Fixed value resistor"},
            "C1": {"type": "capacitor", "description": "Energy storage component"},
            "U1": {"type": "op_amp", "description": "Operational amplifier"}
        }
        
        info = component_db.get(component_id, {
            "type": "unknown",
            "description": f"Component {component_id} requires analysis"
        })
        
        return {
            "success": True,
            "response": json.dumps({
                **info,
                "commonUse": "Various electronic applications",
                "onlineVerification": True,
                "sources": ["Local Electronics Database"]
            })
        }

# Main service loop
analyzer = CircuitAnalyzer()
print("GPT-OSS Circuit Analyzer ready", file=sys.stderr)

while True:
    try:
        line = sys.stdin.readline()
        if not line:
            break
        
        request = json.loads(line.strip())
        result = analyzer.process_request(request["type"], request["data"])
        print(json.dumps(result))
        sys.stdout.flush()
        
    except Exception as e:
        print(json.dumps({"success": False, "error": str(e)}))
        sys.stdout.flush()
`;

    // Write Python script to temporary file
    const scriptPath = path.join(process.cwd(), 'temp', 'gpt_oss_service.py');
    await fs.mkdir(path.dirname(scriptPath), { recursive: true });
    await fs.writeFile(scriptPath, pythonScript);

    // Start Python process
    this.pythonProcess = spawn('python3', [scriptPath], {
      stdio: ['pipe', 'pipe', 'pipe']
    });

    return new Promise((resolve, reject) => {
      let stderr = '';
      this.pythonProcess.stderr.on('data', (data: Buffer) => {
        stderr += data.toString();
        if (stderr.includes('ready')) {
          console.log('Python GPT-OSS service started successfully');
          resolve();
        }
      });

      this.pythonProcess.on('error', (error: Error) => {
        console.error('Python process error:', error);
        reject(error);
      });

      setTimeout(() => {
        if (!stderr.includes('ready')) {
          console.log('Python service starting (this may take a while for large models)...');
          resolve(); // Don't block startup
        }
      }, 5000);
    });
  }

  async analyzeCircuit(description: string): Promise<any> {
    if (!this.pythonProcess) {
      throw new Error('Python service not initialized');
    }

    const request = {
      type: 'circuit_analysis',
      data: { description }
    };

    return this.sendRequest(request);
  }

  async researchComponent(componentId: string, features: string[]): Promise<any> {
    if (!this.pythonProcess) {
      throw new Error('Python service not initialized');
    }

    const request = {
      type: 'component_research',
      data: { componentId, features }
    };

    return this.sendRequest(request);
  }

  private async sendRequest(request: any): Promise<any> {
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        reject(new Error('Request timeout'));
      }, 30000);

      const handleResponse = (data: Buffer) => {
        clearTimeout(timeout);
        this.pythonProcess.stdout.off('data', handleResponse);
        
        try {
          const response = JSON.parse(data.toString().trim());
          resolve(response);
        } catch (error) {
          reject(new Error('Invalid JSON response'));
        }
      };

      this.pythonProcess.stdout.on('data', handleResponse);
      this.pythonProcess.stdin.write(JSON.stringify(request) + '\n');
    });
  }

  async shutdown(): Promise<void> {
    if (this.pythonProcess) {
      this.pythonProcess.kill();
      this.pythonProcess = null;
      this.isModelLoaded = false;
    }
  }
}

export const gptOssService = new GPTOssService();