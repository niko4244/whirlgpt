import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { localAIService } from "./services/localAIService";
import { aiModelRegistry } from "./services/aiModelRegistry";
import { databaseService } from "./services/databaseService";
import multer from 'multer';

// Configure multer for image uploads
const upload = multer({ 
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB limit
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Only image files are allowed'));
    }
  }
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Initialize local AI service
  await localAIService.ensureModelsReady();

  // Circuit analysis endpoint
  app.post('/api/analyze-circuit', upload.single('image'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: 'No image file provided' });
      }

      const analysisResult = await localAIService.analyzeCircuitImage(req.file.buffer);
      
      res.json({
        success: true,
        data: analysisResult,
        processingTime: '2.1s',
        algorithmVersion: 'Local-AI-OSS'
      });
    } catch (error) {
      console.error('Circuit analysis error:', error);
      res.status(500).json({ 
        error: 'Circuit analysis failed', 
        details: (error as Error).message 
      });
    }
  });

  // Component research endpoint
  app.post('/api/research-component', async (req, res) => {
    try {
      const { componentId, features } = req.body;
      
      if (!componentId) {
        return res.status(400).json({ error: 'Component ID is required' });
      }

      const researchResult = await localAIService.researchComponent(
        componentId, 
        features || []
      );
      
      res.json({
        success: true,
        data: researchResult
      });
    } catch (error) {
      console.error('Component research error:', error);
      res.status(500).json({ 
        error: 'Component research failed', 
        details: (error as Error).message 
      });
    }
  });

  // AI model management endpoints
  app.get('/api/ai-models', async (req, res) => {
    try {
      const models = await aiModelRegistry.getAvailableModels();
      res.json({
        success: true,
        models: models.map(model => ({
          ...model,
          modelPath: undefined // Don't expose file paths
        }))
      });
    } catch (error) {
      console.error('Failed to get AI models:', error);
      res.status(500).json({ error: 'Failed to retrieve AI models' });
    }
  });

  app.post('/api/ai-models/:modelId/install', async (req, res) => {
    try {
      const { modelId } = req.params;
      const success = await aiModelRegistry.installModel(modelId);
      
      if (success) {
        res.json({
          success: true,
          message: `Model ${modelId} installed successfully`
        });
      } else {
        res.status(500).json({
          success: false,
          error: `Failed to install model ${modelId}`
        });
      }
    } catch (error) {
      console.error('Model installation error:', error);
      res.status(500).json({ error: 'Model installation failed' });
    }
  });

  app.get('/api/ai-models/capabilities/:capability', async (req, res) => {
    try {
      const { capability } = req.params;
      const models = await aiModelRegistry.findModelsForCapability(capability);
      res.json({
        success: true,
        capability,
        models: models.map(model => ({
          ...model,
          modelPath: undefined
        }))
      });
    } catch (error) {
      console.error('Failed to find models for capability:', error);
      res.status(500).json({ error: 'Failed to find models for capability' });
    }
  });

  // Component database endpoints
  app.post('/api/components', async (req, res) => {
    try {
      const component = await databaseService.addComponent(req.body);
      res.json({ success: true, component });
    } catch (error) {
      console.error('Failed to add component:', error);
      res.status(500).json({ error: 'Failed to add component' });
    }
  });

  app.get('/api/components', async (req, res) => {
    try {
      const { q } = req.query;
      let components;
      
      if (q && typeof q === 'string') {
        components = await databaseService.searchComponents(q);
      } else {
        components = await databaseService.getAllComponents();
      }
      
      res.json({ success: true, components });
    } catch (error) {
      console.error('Failed to get components:', error);
      res.status(500).json({ error: 'Failed to get components' });
    }
  });

  app.get('/api/components/:id', async (req, res) => {
    try {
      const component = await databaseService.getComponent(req.params.id);
      if (component) {
        res.json({ success: true, component });
      } else {
        res.status(404).json({ error: 'Component not found' });
      }
    } catch (error) {
      console.error('Failed to get component:', error);
      res.status(500).json({ error: 'Failed to get component' });
    }
  });

  app.put('/api/components/:id', async (req, res) => {
    try {
      const component = await databaseService.updateComponent(req.params.id, req.body);
      if (component) {
        res.json({ success: true, component });
      } else {
        res.status(404).json({ error: 'Component not found' });
      }
    } catch (error) {
      console.error('Failed to update component:', error);
      res.status(500).json({ error: 'Failed to update component' });
    }
  });

  app.delete('/api/components/:id', async (req, res) => {
    try {
      const success = await databaseService.removeComponent(req.params.id);
      if (success) {
        res.json({ success: true, message: 'Component removed' });
      } else {
        res.status(404).json({ error: 'Component not found' });
      }
    } catch (error) {
      console.error('Failed to remove component:', error);
      res.status(500).json({ error: 'Failed to remove component' });
    }
  });

  app.get('/api/database/stats', async (req, res) => {
    try {
      const stats = await databaseService.getStats();
      res.json({ success: true, stats });
    } catch (error) {
      console.error('Failed to get database stats:', error);
      res.status(500).json({ error: 'Failed to get database stats' });
    }
  });

  app.post('/api/database/backup', async (req, res) => {
    try {
      const backupPath = await databaseService.createBackup();
      res.json({ success: true, backupPath });
    } catch (error) {
      console.error('Failed to create backup:', error);
      res.status(500).json({ error: 'Failed to create backup' });
    }
  });

  // Health check endpoint
  app.get('/api/health', (req, res) => {
    res.json({
      status: 'healthy',
      timestamp: new Date().toISOString(),
      aiService: 'local-circuit-analysis'
    });
  });

  const httpServer = createServer(app);
  return httpServer;
}
