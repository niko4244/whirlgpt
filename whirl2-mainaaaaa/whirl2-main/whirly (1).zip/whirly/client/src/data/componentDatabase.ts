import { ComponentDatabase } from '../types';

export const COMPONENT_DATABASE: ComponentDatabase = {
    resistor: {
        variations: ['zigzag', 'rectangle', 'european', 'american'],
        searchTerms: ['resistor', 'ohm', 'resistance', 'R1', 'R2'],
        visualFeatures: ['zigzag line', 'rectangular box', 'parallel lines'],
        commonValues: ['1kΩ', '10kΩ', '100kΩ', '1MΩ'],
        testKeywords: ['resistance', 'ohm', 'multimeter']
    },
    capacitor: {
        variations: ['electrolytic', 'ceramic', 'polarized', 'non-polarized'],
        searchTerms: ['capacitor', 'cap', 'microfarad', 'C1', 'C2'],
        visualFeatures: ['two parallel lines', 'curved line', 'plus sign'],
        commonValues: ['1µF', '10µF', '100µF', '1000µF'],
        testKeywords: ['capacitance', 'farad', 'charging', 'discharging']
    },
    inductor: {
        variations: ['air core', 'iron core', 'ferrite core', 'coil'],
        searchTerms: ['inductor', 'coil', 'choke', 'L1', 'L2'],
        visualFeatures: ['curved loops', 'spiral', 'coil shape'],
        commonValues: ['1mH', '10mH', '100mH', '1H'],
        testKeywords: ['inductance', 'henry', 'coil', 'magnetic']
    },
    transistor: {
        variations: ['npn', 'pnp', 'bjt', 'fet', 'mosfet'],
        searchTerms: ['transistor', 'bjt', 'fet', 'Q1', 'Q2'],
        visualFeatures: ['arrow', 'three lines', 'circle', 'gate'],
        commonValues: ['2N3904', '2N3906', 'BC547', '2N7000'],
        testKeywords: ['gain', 'amplification', 'switching', 'beta']
    },
    diode: {
        variations: ['standard', 'led', 'zener', 'schottky'],
        searchTerms: ['diode', 'led', 'zener', 'D1', 'D2'],
        visualFeatures: ['triangle', 'line', 'arrow', 'bar'],
        commonValues: ['1N4148', '1N4007', 'LED', '5.1V Zener'],
        testKeywords: ['forward voltage', 'reverse bias', 'rectification']
    },
    op_amp: {
        variations: ['single', 'dual', 'quad', 'rail-to-rail'],
        searchTerms: ['op amp', 'operational amplifier', 'U1', 'IC1'],
        visualFeatures: ['triangle', 'plus minus', 'output'],
        commonValues: ['LM358', 'LM741', 'TL072', 'LM324'],
        testKeywords: ['amplifier', 'gain', 'feedback', 'inverting']
    },
    switch: {
        variations: ['spst', 'spdt', 'dpdt', 'momentary', 'toggle'],
        searchTerms: ['switch', 'button', 'toggle', 'S1', 'SW1'],
        visualFeatures: ['break in line', 'lever', 'contact'],
        commonValues: ['SPST', 'SPDT', 'Push Button', 'Toggle'],
        testKeywords: ['continuity', 'contact resistance', 'switching']
    },
    transformer: {
        variations: ['step-up', 'step-down', 'isolation', 'center-tap'],
        searchTerms: ['transformer', 'xfmr', 'T1', 'TR1'],
        visualFeatures: ['two coils', 'parallel lines', 'core'],
        commonValues: ['120V:12V', '240V:24V', '1:1', '10:1'],
        testKeywords: ['turns ratio', 'isolation', 'primary', 'secondary']
    },
    motor: {
        variations: ['dc', 'ac', 'stepper', 'servo'],
        searchTerms: ['motor', 'M1', 'MOT1'],
        visualFeatures: ['circle', 'M', 'brushes'],
        commonValues: ['DC Motor', 'AC Motor', 'Stepper', 'Servo'],
        testKeywords: ['rpm', 'torque', 'current draw', 'back emf']
    }
};