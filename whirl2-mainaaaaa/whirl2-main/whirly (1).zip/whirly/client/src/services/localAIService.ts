interface LocalAnalysisResult {
  id: string;
  type: string;
  subType?: string;
  estimatedValue?: string;
  box: number[];
  confidence: number;
}

interface LocalConnectionResult {
  id: string;
  type: 'wire';
  path: string;
  confidence: number;
  connectedComponents?: string[];
}

export class LocalAIService {
  private baseUrl: string;

  constructor() {
    this.baseUrl = window.location.origin + '/api';
  }

  async analyzeCircuitImage(imageFile: File): Promise<{
    components: LocalAnalysisResult[];
    connections: LocalConnectionResult[];
  }> {
    const formData = new FormData();
    formData.append('image', imageFile);

    try {
      const response = await fetch(`${this.baseUrl}/analyze-circuit`, {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        throw new Error(`Analysis failed: ${response.statusText}`);
      }

      const result = await response.json();
      
      if (!result.success) {
        throw new Error(result.error || 'Analysis failed');
      }

      return result.data;
    } catch (error) {
      console.error('Local AI analysis failed:', error);
      throw error;
    }
  }

  async researchComponent(componentId: string, features: string[]): Promise<{
    type: string;
    description: string;
    commonUse?: string;
    pinout?: string;
    testProcedure?: string;
    onlineVerification: boolean;
    sources: string[];
  }> {
    try {
      const response = await fetch(`${this.baseUrl}/research-component`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          componentId,
          features
        }),
      });

      if (!response.ok) {
        throw new Error(`Research failed: ${response.statusText}`);
      }

      const result = await response.json();
      
      if (!result.success) {
        throw new Error(result.error || 'Research failed');
      }

      return result.data;
    } catch (error) {
      console.error('Component research failed:', error);
      throw error;
    }
  }

  async checkHealth(): Promise<boolean> {
    try {
      const response = await fetch(`${this.baseUrl}/health`);
      const result = await response.json();
      return result.status === 'healthy';
    } catch {
      return false;
    }
  }
}

export const localAIService = new LocalAIService();