import { Component } from '../types';

interface FeedbackData {
  imageData: string;
  componentBox: number[];
  originalPrediction: {
    type: string;
    confidence: number;
  };
  userCorrection: {
    type: string;
    description: string;
  };
  timestamp: number;
  userId?: string;
}

interface LearningMetrics {
  totalFeedback: number;
  accuracyImprovement: number;
  commonMisclassifications: { [key: string]: number };
  userContributions: number;
}

export class LearningSystem {
  private feedbackData: FeedbackData[] = [];
  private learningMetrics: LearningMetrics = {
    totalFeedback: 0,
    accuracyImprovement: 0,
    commonMisclassifications: {},
    userContributions: 0
  };

  // Store user feedback for learning
  async submitFeedback(
    imageFile: File,
    component: Component,
    userCorrection: { type: string; description: string }
  ): Promise<void> {
    try {
      // Extract component region from image
      const componentImageData = await this.extractComponentRegion(imageFile, component.box);
      
      const feedback: FeedbackData = {
        imageData: componentImageData,
        componentBox: component.box,
        originalPrediction: {
          type: component.type,
          confidence: component.confidence
        },
        userCorrection,
        timestamp: Date.now(),
        userId: this.getUserId()
      };

      this.feedbackData.push(feedback);
      this.updateLearningMetrics(feedback);
      
      // In a real system, this would be sent to a training pipeline
      await this.sendToTrainingPipeline(feedback);
      
      console.log('Feedback submitted for learning:', feedback);
    } catch (error) {
      console.error('Failed to submit feedback:', error);
      throw error;
    }
  }

  private async extractComponentRegion(imageFile: File, box: number[]): Promise<string> {
    return new Promise((resolve, reject) => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d')!;
      const img = new Image();
      
      img.onload = () => {
        const [x, y, width, height] = box;
        canvas.width = width;
        canvas.height = height;
        
        // Draw the component region
        ctx.drawImage(img, x, y, width, height, 0, 0, width, height);
        
        // Convert to base64
        const imageData = canvas.toDataURL('image/png');
        resolve(imageData);
      };
      
      img.onerror = reject;
      img.src = URL.createObjectURL(imageFile);
    });
  }

  private updateLearningMetrics(feedback: FeedbackData): void {
    this.learningMetrics.totalFeedback++;
    this.learningMetrics.userContributions++;
    
    // Track common misclassifications
    const misclassificationKey = `${feedback.originalPrediction.type} -> ${feedback.userCorrection.type}`;
    this.learningMetrics.commonMisclassifications[misclassificationKey] = 
      (this.learningMetrics.commonMisclassifications[misclassificationKey] || 0) + 1;
  }

  private async sendToTrainingPipeline(feedback: FeedbackData): Promise<void> {
    // In a real implementation, this would send data to your ML training pipeline
    // For now, we'll simulate this with local storage for demonstration
    
    try {
      const existingFeedback = JSON.parse(localStorage.getItem('whirly_feedback') || '[]');
      existingFeedback.push(feedback);
      localStorage.setItem('whirly_feedback', JSON.stringify(existingFeedback));
      
      // Simulate API call to training service
      console.log('Feedback sent to training pipeline:', {
        feedbackId: `feedback_${Date.now()}`,
        componentType: feedback.userCorrection.type,
        confidence: feedback.originalPrediction.confidence,
        timestamp: feedback.timestamp
      });
    } catch (error) {
      console.error('Failed to send feedback to training pipeline:', error);
    }
  }

  private getUserId(): string {
    // Generate or retrieve user ID for tracking contributions
    let userId = localStorage.getItem('whirly_user_id');
    if (!userId) {
      userId = `user_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      localStorage.setItem('whirly_user_id', userId);
    }
    return userId;
  }

  // Get learning metrics for display
  getLearningMetrics(): LearningMetrics {
    return { ...this.learningMetrics };
  }

  // Get feedback history
  getFeedbackHistory(): FeedbackData[] {
    return [...this.feedbackData];
  }

  // Analyze learning progress
  getAccuracyTrends(): {
    improvementRate: number;
    commonErrors: Array<{ error: string; count: number }>;
    totalContributions: number;
  } {
    const commonErrors = Object.entries(this.learningMetrics.commonMisclassifications)
      .map(([error, count]) => ({ error, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 5);

    return {
      improvementRate: this.learningMetrics.accuracyImprovement,
      commonErrors,
      totalContributions: this.learningMetrics.userContributions
    };
  }

  // Predict confidence adjustment based on learning
  adjustConfidenceBasedOnLearning(component: Component): number {
    const misclassificationKey = `${component.type} -> `;
    const relatedErrors = Object.keys(this.learningMetrics.commonMisclassifications)
      .filter(key => key.startsWith(misclassificationKey));
    
    if (relatedErrors.length > 0) {
      // Reduce confidence for components that are commonly misclassified
      const errorCount = relatedErrors.reduce((sum, key) => 
        sum + this.learningMetrics.commonMisclassifications[key], 0);
      const confidenceReduction = Math.min(0.2, errorCount * 0.05);
      return Math.max(0.1, component.confidence - confidenceReduction);
    }
    
    return component.confidence;
  }
}

export const learningSystem = new LearningSystem();