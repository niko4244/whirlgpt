interface GeminiAnalysisResult {
  id: string;
  type: string;
  subType?: string;
  estimatedValue?: string;
  box: number[];
  confidence: number;
}

interface GeminiConnectionResult {
  id: string;
  type: 'wire';
  path: string;
  confidence: number;
  connectedComponents?: string[];
}

export class GeminiVisionService {
  private apiKey: string;
  private baseUrl = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-exp:generateContent';

  constructor(apiKey?: string) {
    this.apiKey = apiKey || import.meta.env.VITE_GEMINI_API_KEY || '';
  }

  private getAnalysisPrompt(): string {
    return `Analyze the uploaded image, which is an electronic circuit diagram. Your task is to accurately identify and classify all electronic components present in the diagram. For each identified component, provide the following information:

1. **id**: The component's labeled identifier (e.g., 'R1', 'C2', 'U3', 'Q4'). If no explicit label is present, generate a unique, logical identifier (e.g., 'Resistor_1', 'Capacitor_A').
2. **type**: The general category of the component (e.g., 'resistor', 'capacitor', 'inductor', 'diode', 'transistor', 'op_amp', 'switch', 'transformer', 'motor', 'ic', 'fuse', 'led', 'battery', 'ground', 'connector', 'crystal', 'speaker', 'microphone', 'sensor', 'other').
3. **subType** (optional): A more specific classification if discernible (e.g., for 'resistor': 'fixed', 'variable'; for 'capacitor': 'electrolytic', 'ceramic'; for 'transistor': 'NPN', 'MOSFET').
4. **estimatedValue** (optional): Any discernible value or rating (e.g., '10kΩ', '100µF', '5V', 'LM358').
5. **box**: The bounding box coordinates of the component in the format [x_min, y_min, width, height] relative to the top-left corner of the image.
6. **confidence**: A numerical value (0.0 to 1.0) indicating your confidence in the identification.

Additionally, identify any clear **connections or wires** between components. For each connection, provide:

1. **id**: A unique identifier for the wire/connection.
2. **type**: Always 'wire' for connections.
3. **path**: A simplified representation of its path (e.g., 'M x1 y1 L x2 y2' for a straight line, or a series of points for more complex paths).
4. **confidence**: Confidence in the connection identification.
5. **connectedComponents**: Array of component IDs that this wire connects.

If you encounter any symbols or components that are **unclear, ambiguous, or not recognized** with high confidence, list their approximate location and a brief description of what they appear to be, marking their **type** as 'unknown' and providing a lower **confidence** score.

Respond strictly in JSON format with two arrays: "components" and "connections". Ensure all numerical values are actual numbers, not strings. Do not include any conversational text outside the JSON.

Example response format:
{
  "components": [
    {
      "id": "R1",
      "type": "resistor",
      "subType": "fixed",
      "estimatedValue": "10kΩ",
      "box": [120, 180, 45, 15],
      "confidence": 0.98
    }
  ],
  "connections": [
    {
      "id": "wire_R1_U1",
      "type": "wire",
      "path": "M 165 187 L 200 187",
      "confidence": 0.95,
      "connectedComponents": ["R1", "U1"]
    }
  ]
}`;
  }

  async analyzeCircuitImage(imageFile: File): Promise<{
    components: GeminiAnalysisResult[];
    connections: GeminiConnectionResult[];
  }> {
    if (!this.apiKey) {
      throw new Error('Gemini API key not configured. Please set VITE_GEMINI_API_KEY environment variable.');
    }

    try {
      // Convert image to base64
      const base64Image = await this.fileToBase64(imageFile);
      const mimeType = imageFile.type;

      const requestBody = {
        contents: [
          {
            parts: [
              {
                text: this.getAnalysisPrompt()
              },
              {
                inline_data: {
                  mime_type: mimeType,
                  data: base64Image
                }
              }
            ]
          }
        ],
        generationConfig: {
          temperature: 0.1,
          topK: 32,
          topP: 1,
          maxOutputTokens: 4096,
        }
      };

      const response = await fetch(`${this.baseUrl}?key=${this.apiKey}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(requestBody)
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(`Gemini API error: ${errorData.error?.message || response.statusText}`);
      }

      const data = await response.json();
      const content = data.candidates?.[0]?.content?.parts?.[0]?.text;

      if (!content) {
        throw new Error('No analysis content received from Gemini API');
      }

      // Parse the JSON response
      const analysisResult = this.parseGeminiResponse(content);
      return analysisResult;

    } catch (error) {
      console.error('Gemini Vision API error:', error);
      throw new Error(`Failed to analyze image: ${(error as Error).message}`);
    }
  }

  private parseGeminiResponse(content: string): {
    components: GeminiAnalysisResult[];
    connections: GeminiConnectionResult[];
  } {
    try {
      // Clean the response - remove any markdown formatting
      const cleanContent = content.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
      
      const parsed = JSON.parse(cleanContent);
      
      return {
        components: parsed.components || [],
        connections: parsed.connections || []
      };
    } catch (error) {
      console.error('Failed to parse Gemini response:', content);
      throw new Error('Invalid JSON response from Gemini API');
    }
  }

  private async fileToBase64(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        const base64 = (reader.result as string).split(',')[1];
        resolve(base64);
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  }

  async researchComponent(componentId: string, visualFeatures: string[], imageSnippet?: string): Promise<{
    type: string;
    description: string;
    commonUse?: string;
    pinout?: string;
    testProcedure?: string;
    onlineVerification: boolean;
    sources: string[];
    confidence: number;
  }> {
    if (!this.apiKey) {
      throw new Error('Gemini API key not configured');
    }

    const researchPrompt = `Research the electronic component with ID "${componentId}" based on the following visual features: ${visualFeatures.join(', ')}.

Provide detailed information about this component including:
1. **type**: The specific component type
2. **description**: Detailed description of what this component is and does
3. **commonUse**: Common applications and use cases
4. **pinout**: Pin configuration if applicable
5. **testProcedure**: How to test this component with standard equipment
6. **confidence**: Your confidence level (0.0 to 1.0) in this identification

Respond in JSON format only:
{
  "type": "component_type",
  "description": "detailed description",
  "commonUse": "common applications",
  "pinout": "pin configuration",
  "testProcedure": "testing instructions",
  "confidence": 0.95
}`;

    try {
      const requestBody = {
        contents: [
          {
            parts: [
              {
                text: researchPrompt
              }
            ]
          }
        ],
        generationConfig: {
          temperature: 0.2,
          maxOutputTokens: 2048,
        }
      };

      const response = await fetch(`${this.baseUrl}?key=${this.apiKey}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(requestBody)
      });

      if (!response.ok) {
        throw new Error(`Research API error: ${response.statusText}`);
      }

      const data = await response.json();
      const content = data.candidates?.[0]?.content?.parts?.[0]?.text;

      if (!content) {
        throw new Error('No research content received');
      }

      const cleanContent = content.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
      const result = JSON.parse(cleanContent);

      return {
        ...result,
        onlineVerification: true,
        sources: ['Gemini AI Knowledge Base', 'Component Databases']
      };

    } catch (error) {
      console.error('Component research failed:', error);
      return {
        type: 'unknown',
        description: 'Component research failed',
        onlineVerification: false,
        sources: [],
        confidence: 0.0
      };
    }
  }
}

export const geminiVisionService = new GeminiVisionService();