export interface Component {
  id: string;
  type: string;
  box: number[];
  confidence: number;
  features: string[];
  estimatedValue?: string;
  verified?: boolean;
  userDefined?: boolean;
  description?: string;
  centerPoint?: { x: number; y: number };
  connectionPoints?: { x: number; y: number }[];
}

export interface Wire {
  id: string;
  path: string;
  confidence: number;
  connectionPoints?: number[][];
  connectedComponents?: string[];
}

export interface CircuitData {
  viewBox: string;
  components: Component[];
  wires: Wire[];
  connectionGraph?: { [key: string]: string[] };
  svgData?: string;
  unknownComponents: string[];
  analysisMetadata: {
    processingTime: string;
    algorithmVersion: string;
    totalComponents: number;
    avgConfidence: number;
    imageSize?: { width: number; height: number };
  };
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
  confidence?: number;
}

export interface ResearchJob {
  componentId: string;
  status: 'researching' | 'completed' | 'failed';
  startTime: number;
  result?: ResearchResult;
  error?: string;
}

export interface ResearchResult {
  type: string;
  description: string;
  commonUse?: string;
  pinout?: string;
  testProcedure?: string;
  onlineVerification: boolean;
  sources: string[];
}

export interface ComponentType {
  variations: string[];
  searchTerms: string[];
  visualFeatures: string[];
  commonValues: string[];
  testKeywords: string[];
  userDefinitions?: Array<{
    componentId: string;
    definition: string;
  }>;
}

export type ComponentDatabase = Record<string, ComponentType>;

export interface ComponentDefinition {
  id: string;
  type: string;
  description: string;
  definition: string;
  commonUse?: string;
  pinout?: string;
  testProcedure?: string;
}