import React, { useState, useRef, useEffect } from 'react';
import { UploadCloud, UserCircle as LoaderCircle, BrainCircuit, AlertTriangle, Send, User, Bot, Eraser, BookUp, X, ZoomIn, ZoomOut, Search, Eye, Database, Wifi, CheckCircle, XCircle, Brain } from 'lucide-react';
import { WhirlyLogo } from './components/WhirlyLogo';
import { ResearchStatus } from './components/ResearchStatus';
import { ComponentDefinitionModal } from './components/ComponentDefinitionModal';
import { ChatMessage } from './components/ChatMessage';
import { VectorDiagramViewer } from './components/VectorDiagramViewer';
import { localAIService } from './services/localAIService';
import { learningSystem } from './services/learningSystem';
import { ComponentDatabaseManager } from './components/ComponentDatabaseManager';
import { LearningDashboard } from './components/LearningDashboard';
import { COMPONENT_DATABASE } from './data/componentDatabase';
import { processAIQuestion } from './utils/aiQuestions';
import type { CircuitData, ChatMessage as ChatMessageType, ResearchJob, ComponentDefinition } from './types';

function App() {
    const [diagramFile, setDiagramFile] = useState<File | null>(null);
    const [chatHistory, setChatHistory] = useState<ChatMessageType[]>([]);
    const [userInput, setUserInput] = useState('');
    const [status, setStatus] = useState<'idle' | 'reconstructing' | 'processing'>('idle');
    const [notification, setNotification] = useState<string | null>(null);
    const [circuitData, setCircuitData] = useState<CircuitData | null>(null);
    const [highlightedElements, setHighlightedElements] = useState<string[]>([]);
    const [highlightedWires, setHighlightedWires] = useState<string[]>([]);
    const [zoom, setZoom] = useState(1);
    const [showComponentDefinition, setShowComponentDefinition] = useState(false);
    const [researchJobs, setResearchJobs] = useState<ResearchJob[]>([]);
    const [knowledgeBase, setKnowledgeBase] = useState(COMPONENT_DATABASE);
    // Removed Gemini API key requirement - using local AI now
    const [showLearningDashboard, setShowLearningDashboard] = useState(false);

    const chatEndRef = useRef<HTMLDivElement>(null);
    const diagramInputRef = useRef<HTMLInputElement>(null);

    // Auto-scroll chat
    useEffect(() => {
        chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [chatHistory]);

    const handleDiagramFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file || !file.type.startsWith('image/')) {
            setNotification('Please upload a valid image file (JPG, PNG, GIF, WebP).');
            return;
        }

        setDiagramFile(file);
        setChatHistory([]);
        setCircuitData(null);
        setHighlightedElements([]);
        setHighlightedWires([]);
        setResearchJobs([]);
        setStatus('reconstructing');
        setNotification('Starting advanced AI analysis of circuit diagram...');

        try {
            // Use Local AI for real analysis
            const { components, connections } = await localAIService.analyzeCircuitImage(file);
            
            // Convert to our CircuitData format
            const analysisResult: CircuitData = {
                viewBox: `0 0 ${file.size > 1000000 ? 1920 : 1280} ${file.size > 1000000 ? 1080 : 720}`,
                components: components.map(comp => ({
                    ...comp,
                    features: comp.subType ? [comp.subType] : [],
                    centerPoint: {
                        x: comp.box[0] + comp.box[2] / 2,
                        y: comp.box[1] + comp.box[3] / 2
                    },
                    connectionPoints: [
                        { x: comp.box[0], y: comp.box[1] + comp.box[3] / 2 },
                        { x: comp.box[0] + comp.box[2], y: comp.box[1] + comp.box[3] / 2 }
                    ]
                })),
                wires: connections.map(conn => ({
                    id: conn.id,
                    path: conn.path,
                    confidence: conn.confidence,
                    connectedComponents: conn.connectedComponents
                })),
                unknownComponents: components
                    .filter(comp => comp.type === 'unknown' || comp.confidence < 0.7)
                    .map(comp => comp.id),
                analysisMetadata: {
                    processingTime: '2.1s',
                    algorithmVersion: 'Local-AI-OSS',
                    totalComponents: components.length,
                    avgConfidence: components.reduce((sum, c) => sum + c.confidence, 0) / components.length
                }
            };
            
            // Filter components to only highlight those with high confidence
            const initialHighlighted = analysisResult.components
                .filter(comp => comp.confidence >= 0.8)
                .map(comp => comp.id);

            setCircuitData(analysisResult);
            setHighlightedElements(initialHighlighted);
            setStatus('idle');
            setNotification(
                `Analysis complete! Identified ${analysisResult.components.length} components ` +
                `(${analysisResult.unknownComponents.length} need research). You can now ask questions.`
            );

            // Add initial analysis to chat
            const analysisText = `🔍 **Circuit Analysis Complete**\n\n` +
                `Found ${analysisResult.components.length} components:\n` +
                analysisResult.components.map(comp =>
                    `• ${comp.id}: ${comp.type} (${Math.round(comp.confidence * 100)}% confidence)${comp.estimatedValue ? ` - ${comp.estimatedValue}` : ''}`
                ).join('\n') +
                (analysisResult.unknownComponents.length > 0 ?
                    `\n\n⚠️ Components needing research: ${analysisResult.unknownComponents.join(', ')}` : '');

            setChatHistory([{
                role: 'model',
                text: analysisText,
                confidence: analysisResult.analysisMetadata.avgConfidence
            }]);

        } catch (error) {
            console.error("Enhanced analysis failed:", error);
            setNotification(`Analysis failed: ${(error as Error).message}`);
            setStatus('idle');
            setDiagramFile(null);
        }
    };

    const handleResearchComponent = async (componentId: string) => {
        const component = circuitData?.components.find(c => c.id === componentId);
        if (!component) return;

        // Add research job
        const newJob: ResearchJob = {
            componentId,
            status: 'researching',
            startTime: Date.now()
        };
        setResearchJobs(prev => [...prev, newJob]);
        setNotification(`Researching ${componentId} online...`);

        try {
            const researchResult = await localAIService.researchComponent(
                componentId,
                component.features || []
            );

            // Update research job
            setResearchJobs(prev => prev.map(job =>
                job.componentId === componentId
                    ? { ...job, status: 'completed', result: researchResult }
                    : job
            ));

            // Update circuit data and highlights based on research
            if (researchResult.onlineVerification) {
                setCircuitData(prev => prev ? ({
                    ...prev,
                    components: prev.components.map(comp =>
                        comp.id === componentId
                            ? { ...comp, type: researchResult.type, verified: true }
                            : comp
                    ),
                    unknownComponents: prev.unknownComponents.filter(id => id !== componentId)
                }) : null);
                
                // Add to highlighted elements if successfully verified
                setHighlightedElements(prev => [...Array.from(new Set([...prev, componentId]))]);
                setNotification(`✅ ${componentId} identified as ${researchResult.type} through online research!`);

                // Add research result to chat
                const researchText = `🔬 **Research Complete: ${componentId}**\n\n` +
                    `Type: ${researchResult.type}\n` +
                    `Description: ${researchResult.description}\n` +
                    (researchResult.commonUse ? `Common Use: ${researchResult.commonUse}\n` : '') +
                    (researchResult.testProcedure ? `Test Procedure: ${researchResult.testProcedure}\n` : '') +
                    `✓ Verified through online sources`;
                setChatHistory(prev => [...prev, {
                    role: 'model',
                    text: researchText,
                    confidence: 0.95
                }]);
            } else {
                setNotification(`❌ Could not verify ${componentId} through online research`);
            }
        } catch (error) {
            console.error(`Research failed for ${componentId}:`, error);
            setResearchJobs(prev => prev.map(job =>
                job.componentId === componentId
                    ? { ...job, status: 'failed', error: (error as Error).message }
                    : job
            ));
            setNotification(`Research failed for ${componentId}: ${(error as Error).message}`);
        }
    };

    const handleDefineComponent = async (componentId: string, definition: string, componentType: string) => {
        const component = circuitData?.components.find(c => c.id === componentId);
        
        // Submit feedback to learning system
        if (component && diagramFile) {
            try {
                await learningSystem.submitFeedback(
                    diagramFile,
                    component,
                    { type: componentType, description: definition }
                );
            } catch (error) {
                console.error('Failed to submit learning feedback:', error);
            }
        }
        
        // Update circuit data
        setCircuitData(prev => prev ? ({
            ...prev,
            components: prev.components.map(comp =>
                comp.id === componentId
                    ? { ...comp, type: componentType, description: definition, userDefined: true, verified: true }
                    : comp
            ),
            unknownComponents: prev.unknownComponents.filter(id => id !== componentId)
        }) : null);

        // Add to highlighted elements if user defined
        setHighlightedElements(prev => [...Array.from(new Set([...prev, componentId]))]);

        // Update knowledge base (mock)
        setKnowledgeBase(prev => ({
            ...prev,
            [componentType]: {
                ...prev[componentType],
                userDefinitions: [
                    ...(prev[componentType]?.userDefinitions || []),
                    { componentId, definition }
                ]
            }
        }));

        setNotification(`✅ Successfully defined ${componentId} as ${componentType}`);
        setTimeout(() => setNotification(null), 3000);

        // Add to chat history
        setChatHistory(prev => [...prev, {
            role: 'model',
            text: `📝 **User Definition Added**\n\n${componentId} has been defined as: ${componentType}\n\nDescription: ${definition}`,
            confidence: 1.0
        }]);
    };

    const handleAskAI = async () => {
        if (!userInput.trim() || !circuitData) return;

        setHighlightedElements([]); // Clear highlights on new question
        setHighlightedWires([]);
        setStatus('processing');
        const currentQuestion = userInput.toLowerCase();
        setChatHistory(prev => [...prev, { role: 'user', text: userInput }]);
        setUserInput('');

        // Simulate AI processing
        await new Promise(resolve => setTimeout(resolve, 2000));

        try {
            const { response, elementsToHighlight, wiresToHighlight } = await processAIQuestion(
                currentQuestion,
                circuitData,
                knowledgeBase
            );

            setChatHistory(prev => [...prev, {
                role: 'model',
                text: response,
                confidence: 0.92
            }]);

            if (elementsToHighlight.length > 0) {
                setHighlightedElements(elementsToHighlight);
            }
            if (wiresToHighlight.length > 0) {
                setHighlightedWires(wiresToHighlight);
            }
            if (elementsToHighlight.length > 0 || wiresToHighlight.length > 0) {
                setNotification(`Highlighted: ${[...elementsToHighlight, ...wiresToHighlight].join(', ')}`);
                setTimeout(() => setNotification(null), 4000);
            }
        } catch (error) {
            console.error('AI processing error:', error);
            setChatHistory(prev => [...prev, {
                role: 'model',
                text: `Sorry, I encountered an error processing your request: ${(error as Error).message}`
            }]);
        }
        setStatus('idle');
    };

    const clearResearchJobs = () => {
        setResearchJobs([]);
    };

    const getButtonText = () => {
        if (status === 'reconstructing') return 'Analyzing with AI Vision...';
        if (diagramFile) return 'Upload New Diagram';
        return 'Upload Circuit Diagram';
    };

    return (
        <>
            <style>
                {`
                @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Inter:wght@400;600&family=Lobster+Two:wght@700&display=swap');
                .font-whirly {
                    font-family: 'Lobster Two', cursive;
                }
                .font-serif-classic {
                    font-family: 'Playfair Display', serif;
                }
                .font-sans-pro {
                    font-family: 'Inter', sans-serif;
                }
                .line-clamp-2 {
                    display: -webkit-box;
                    -webkit-line-clamp: 2;
                    -webkit-box-orient: vertical;
                    overflow: hidden;
                }
                `}
            </style>
            <div className="bg-neutral-900 min-h-screen text-neutral-100 font-sans-pro flex flex-col h-screen overflow-hidden pt-8 px-8">
                <header className="text-center mb-8 flex-shrink-0">
                    <h1 className="text-7xl font-whirly text-white flex items-center justify-center gap-4 drop-shadow-lg">
                        <WhirlyLogo />
                        Whirly
                    </h1>
                    <p className="text-xl text-orange-200 mt-4 font-serif-classic">Advanced AI Circuit Analysis & Component Recognition</p>
                </header>

                {notification && (
                    <div className="w-full max-w-7xl mx-auto my-4 bg-orange-900/40 border border-orange-600 text-orange-200 px-4 py-3 rounded-lg text-sm flex items-center gap-2 flex-shrink-0 shadow-md">
                        <AlertTriangle className="h-5 w-5"/>
                        <span>{notification}</span>
                    </div>
                )}

                <main className="flex-grow grid grid-cols-1 md:grid-cols-2 gap-8 max-w-7xl w-full mx-auto py-4 min-h-0">
                    <div className="bg-neutral-800 rounded-xl shadow-lg p-6 flex flex-col border border-neutral-700 flex-grow">
                        <div className="flex justify-between items-center mb-4 flex-shrink-0">
                            <h2 className="text-3xl font-serif-classic font-bold text-neutral-100">Circuit Analysis</h2>
                            <div className="flex items-center gap-2">
                                <button
                                    onClick={() => setZoom(z => Math.min(z * 1.2, 3))}
                                    className="p-2 text-neutral-400 hover:bg-neutral-700 hover:text-neutral-100 rounded-md transition-colors"
                                    disabled={zoom >= 3}
                                >
                                    <ZoomIn size={18}/>
                                </button>
                                <button
                                    onClick={() => setZoom(z => Math.max(z / 1.2, 0.5))}
                                    className="p-2 text-neutral-400 hover:bg-neutral-700 hover:text-neutral-100 rounded-md transition-colors"
                                    disabled={zoom <= 0.5}
                                >
                                    <ZoomOut size={18}/>
                                </button>
                                <button
                                    onClick={() => {
                                        setHighlightedElements([]);
                                        setHighlightedWires([]);
                                    }}
                                    className="flex items-center gap-2 text-sm bg-neutral-700 hover:bg-neutral-600 text-neutral-100 py-2 px-4 rounded-lg transition-colors disabled:opacity-50"
                                    disabled={highlightedElements.length === 0 && highlightedWires.length === 0}
                                >
                                    <Eraser className="h-4 w-4" /> Clear
                                </button>
                                {circuitData?.unknownComponents && circuitData.unknownComponents.length > 0 && (
                                    <button
                                        onClick={() => setShowComponentDefinition(true)}
                                        className="flex items-center gap-2 text-sm bg-orange-600 hover:bg-orange-700 text-white py-2 px-4 rounded-lg transition-colors"
                                    >
                                        <AlertTriangle className="h-4 w-4" /> Define ({circuitData.unknownComponents.length})
                                    </button>
                                )}
                               <button
                                   onClick={() => setShowLearningDashboard(!showLearningDashboard)}
                                   className="flex items-center gap-2 text-sm bg-purple-600 hover:bg-purple-700 text-white py-2 px-4 rounded-lg transition-colors"
                               >
                                   <Brain className="h-4 w-4" /> Learning
                               </button>
                            </div>
                        </div>
                        <div className="flex-grow bg-neutral-900 rounded-lg flex items-center justify-center relative overflow-hidden border border-neutral-700 h-full">
                            <div className="w-full h-full" style={{ transform: `scale(${zoom})`, transition: 'transform 0.2s' }}>
                                <VectorDiagramViewer
                                    diagramFile={diagramFile}
                                    circuitData={circuitData}
                                    highlightedElements={highlightedElements}
                                    highlightedWires={highlightedWires}
                                    status={status}
                                    onComponentClick={(elementId: string) => {
                                        setHighlightedElements([elementId]);
                                        setHighlightedWires([]);
                                    }}
                                    onWireClick={(elementId: string) => {
                                        setHighlightedWires([elementId]);
                                        setHighlightedElements([]);
                                    }}
                                />
                            </div>
                        </div>
                        <input
                            type="file"
                            id="diagram-upload"
                            className="hidden"
                            accept="image/*"
                            onChange={handleDiagramFileChange}
                            ref={diagramInputRef}
                        />
                        <button
                            onClick={() => diagramInputRef.current?.click()}
                            disabled={status === 'reconstructing'}
                            className="w-full mt-4 bg-red-700 text-white font-bold py-3 px-4 rounded-lg hover:bg-red-800 transition-colors cursor-pointer text-center flex-shrink-0 disabled:bg-neutral-700 disabled:text-neutral-400 disabled:cursor-not-allowed"
                        >
                            {getButtonText()}
                        </button>
                    </div>
                    <div className="bg-neutral-800 rounded-xl shadow-lg p-6 flex flex-col border border-neutral-700 flex-grow">
                        <h2 className="text-3xl font-serif-classic font-bold mb-4 text-neutral-100 flex-shrink-0">Ask Whirly AI</h2>
                        <div className="flex-grow bg-neutral-900 rounded-lg p-4 overflow-y-auto flex flex-col border border-neutral-700 h-full">
                            {chatHistory.length === 0 ? (
                                <div className="m-auto text-center text-neutral-500 font-sans-pro">
                                    <BrainCircuit className="h-12 w-12 mx-auto mb-4 text-neutral-600" />
                                    <p className="text-base mb-3">Upload a circuit diagram to start analysis</p>
                                    <div className="text-sm text-neutral-600 space-y-1">
                                        <p><strong>Try asking:</strong></p>
                                        <p>• "Trace the signal path through this circuit"</p>
                                        <p>• "How do I test transistor Q1?"</p>
                                        <p>• "What's the purpose of capacitor C1?"</p>
                                        <p>• "Explain how this amplifier works"</p>
                                    </div>
                                </div>
                            ) : (
                                <>
                                    {chatHistory.map((msg, index) => <ChatMessage key={index} message={msg} />)}
                                    <div ref={chatEndRef} />
                                </>
                            )}
                        </div>
                        <div className="mt-4 flex items-center gap-3 flex-shrink-0">
                            <input
                                type="text"
                                value={userInput}
                                onChange={(e) => setUserInput(e.target.value)}
                                onKeyPress={(e) => e.key === 'Enter' && !e.shiftKey && handleAskAI()}
                                placeholder={circuitData ? "Ask about the circuit..." : "Upload a diagram to start"}
                                className="flex-grow bg-neutral-700 border border-neutral-600 rounded-lg p-3 text-neutral-100 placeholder-neutral-500 focus:outline-none focus:ring-2 focus:ring-red-700"
                                disabled={!circuitData || status === 'processing'}
                            />
                            <button
                                onClick={handleAskAI}
                                disabled={!circuitData || status === 'processing' || !userInput.trim()}
                                className="bg-red-700 text-white p-3 rounded-lg hover:bg-red-800 disabled:bg-neutral-700 disabled:text-neutral-400 disabled:cursor-not-allowed transition-colors"
                            >
                                {status === 'processing' ? <LoaderCircle className="animate-spin h-6 w-6" /> : <Send className="h-6 w-6" />}
                            </button>
                        </div>
                    </div>
                </main>

                {/* Component Definition Modal */}
                {showComponentDefinition && circuitData?.unknownComponents && (
                    <ComponentDefinitionModal
                        unknownComponents={circuitData.unknownComponents}
                        onDefine={handleDefineComponent}
                        onClose={() => setShowComponentDefinition(false)}
                        onResearch={handleResearchComponent}
                    />
                )}

                {/* Research Status Panel */}
                <ResearchStatus researchJobs={researchJobs} />

               {/* AI Model Status - Non-intrusive notification */}
               <div className="fixed bottom-4 right-4 z-40 max-w-xs">
                   <div className="bg-neutral-800 text-neutral-300 text-xs px-3 py-2 rounded-lg border border-neutral-600 shadow-lg">
                       <div className="flex items-center gap-2">
                           <div className="animate-pulse w-2 h-2 bg-green-400 rounded-full"></div>
                           <span>Local AI Processing Active</span>
                       </div>
                   </div>
               </div>

               {/* Learning Dashboard */}
               {showLearningDashboard && (
                   <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50">
                       <div className="bg-neutral-900 rounded-xl shadow-xl border border-neutral-700 p-6 w-full max-w-4xl mx-4 max-h-[80vh] overflow-y-auto">
                           <div className="flex justify-between items-center mb-4">
                               <h2 className="text-2xl font-serif-classic font-bold text-neutral-100">AI Learning Dashboard</h2>
                               <button
                                   onClick={() => setShowLearningDashboard(false)}
                                   className="text-neutral-400 hover:text-white"
                               >
                                   <X className="h-6 w-6" />
                               </button>
                           </div>
                           <LearningDashboard />
                       </div>
                   </div>
               )}

                {/* Footer with enhanced knowledge base info */}
                <footer className="mt-8 max-w-7xl w-full mx-auto flex-shrink-0 pb-8">
                    <div className="bg-neutral-800 rounded-xl shadow-lg p-6 border border-neutral-700">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            {/* Component Database Manager */}
                            <ComponentDatabaseManager />
                            <div>
                                <h3 className="text-xl font-serif-classic font-bold mb-3 text-neutral-100 flex items-center gap-2">
                                    <Brain className="h-5 w-5 text-purple-400" />
                                    Local AI Vision
                                </h3>
                                <div className="text-sm text-neutral-400 space-y-2">
                                    <p>Powered by Open Source AI:</p>
                                    <ul className="text-xs space-y-1">
                                        <li>• Local AI image analysis</li>
                                        <li>• Component shape and symbol recognition</li>
                                        <li>• Wire tracing and connection mapping</li>
                                        <li>• Continuous learning from user feedback</li>
                                        <li>• ✅ No API keys required</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        {researchJobs.length > 0 && (
                            <div className="mt-4 pt-4 border-t border-neutral-700">
                                <div className="flex justify-between items-center">
                                    <span className="text-sm text-neutral-400">
                                        Research jobs: {researchJobs.filter(j => j.status === 'completed').length}/{researchJobs.length} completed
                                    </span>
                                    <button
                                        onClick={clearResearchJobs}
                                        className="text-xs text-orange-400 hover:text-white transition-colors"
                                    >
                                        Clear history
                                    </button>
                                </div>
                            </div>
                        )}
                    </div>
                </footer>
            </div>
        </>
    );
}

export default App;