import React, { useState, useEffect } from 'react';
import { Plus, Search, Database, Trash2, Edit, Save, X } from 'lucide-react';

interface ComponentDefinition {
  id: string;
  type: string;
  subType?: string;
  description: string;
  commonUse?: string;
  pinout?: string;
  testProcedure?: string;
  userDefined: boolean;
  verified: boolean;
  createdAt: string;
  sources: string[];
}

interface DatabaseStats {
  totalComponents: number;
  userDefined: number;
  verified: number;
  byType: Record<string, number>;
}

export const ComponentDatabaseManager: React.FC = () => {
  const [components, setComponents] = useState<ComponentDefinition[]>([]);
  const [stats, setStats] = useState<DatabaseStats | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [isAdding, setIsAdding] = useState(false);
  const [editingComponent, setEditingComponent] = useState<ComponentDefinition | null>(null);
  const [loading, setLoading] = useState(true);
  
  const [newComponent, setNewComponent] = useState({
    id: '',
    type: 'resistor',
    subType: '',
    description: '',
    commonUse: '',
    testProcedure: ''
  });

  useEffect(() => {
    loadComponents();
    loadStats();
  }, []);

  useEffect(() => {
    if (searchQuery) {
      searchComponents();
    } else {
      loadComponents();
    }
  }, [searchQuery]);

  const loadComponents = async () => {
    try {
      const response = await fetch('/api/components');
      const data = await response.json();
      if (data.success) {
        setComponents(data.components);
      }
    } catch (error) {
      console.error('Failed to load components:', error);
    } finally {
      setLoading(false);
    }
  };

  const searchComponents = async () => {
    try {
      const response = await fetch(`/api/components?q=${encodeURIComponent(searchQuery)}`);
      const data = await response.json();
      if (data.success) {
        setComponents(data.components);
      }
    } catch (error) {
      console.error('Failed to search components:', error);
    }
  };

  const loadStats = async () => {
    try {
      const response = await fetch('/api/database/stats');
      const data = await response.json();
      if (data.success) {
        setStats(data.stats);
      }
    } catch (error) {
      console.error('Failed to load stats:', error);
    }
  };

  const addComponent = async () => {
    try {
      const response = await fetch('/api/components', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newComponent)
      });
      
      const data = await response.json();
      if (data.success) {
        setComponents(prev => [data.component, ...prev]);
        setNewComponent({ id: '', type: 'resistor', subType: '', description: '', commonUse: '', testProcedure: '' });
        setIsAdding(false);
        loadStats();
      }
    } catch (error) {
      console.error('Failed to add component:', error);
    }
  };

  const updateComponent = async () => {
    if (!editingComponent) return;
    
    try {
      const response = await fetch(`/api/components/${editingComponent.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(editingComponent)
      });
      
      const data = await response.json();
      if (data.success) {
        setComponents(prev => prev.map(c => c.id === editingComponent.id ? data.component : c));
        setEditingComponent(null);
      }
    } catch (error) {
      console.error('Failed to update component:', error);
    }
  };

  const deleteComponent = async (componentId: string) => {
    if (!confirm('Are you sure you want to delete this component?')) return;
    
    try {
      const response = await fetch(`/api/components/${componentId}`, {
        method: 'DELETE'
      });
      
      const data = await response.json();
      if (data.success) {
        setComponents(prev => prev.filter(c => c.id !== componentId));
        loadStats();
      }
    } catch (error) {
      console.error('Failed to delete component:', error);
    }
  };

  const componentTypes = [
    'resistor', 'capacitor', 'inductor', 'diode', 'transistor', 'op_amp', 
    'microcontroller', 'crystal', 'switch', 'connector', 'led', 'sensor', 'other'
  ];

  if (loading) {
    return (
      <div className="bg-neutral-800 rounded-xl p-6 border border-neutral-700">
        <div className="animate-pulse">
          <div className="h-6 bg-neutral-700 rounded w-1/3 mb-4"></div>
          <div className="space-y-3">
            {[1, 2, 3].map(i => (
              <div key={i} className="h-16 bg-neutral-700 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-neutral-800 rounded-xl p-6 border border-neutral-700">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <Database className="h-6 w-6 text-blue-400" />
          <h3 className="text-xl font-serif-classic font-bold text-neutral-100">
            Component Database
          </h3>
          {stats && (
            <span className="text-sm text-neutral-400">
              ({stats.totalComponents} total, {stats.userDefined} custom)
            </span>
          )}
        </div>
        
        <button
          onClick={() => setIsAdding(true)}
          className="flex items-center gap-2 px-3 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm rounded-md transition-colors"
        >
          <Plus className="h-4 w-4" />
          Add Component
        </button>
      </div>

      {/* Search Bar */}
      <div className="relative mb-4">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-neutral-400" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search components..."
          className="w-full pl-10 pr-4 py-2 bg-neutral-700 border border-neutral-600 rounded-md text-neutral-100 placeholder-neutral-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
      </div>

      {/* Add Component Form */}
      {isAdding && (
        <div className="bg-neutral-700 rounded-lg p-4 mb-4 border border-neutral-600">
          <h4 className="font-semibold text-neutral-100 mb-3">Add New Component</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
            <input
              type="text"
              value={newComponent.id}
              onChange={(e) => setNewComponent({...newComponent, id: e.target.value})}
              placeholder="Component ID (e.g., R1, C1)"
              className="px-3 py-2 bg-neutral-600 border border-neutral-500 rounded text-neutral-100 placeholder-neutral-400"
            />
            <select
              value={newComponent.type}
              onChange={(e) => setNewComponent({...newComponent, type: e.target.value})}
              className="px-3 py-2 bg-neutral-600 border border-neutral-500 rounded text-neutral-100"
            >
              {componentTypes.map(type => (
                <option key={type} value={type}>
                  {type.replace('_', ' ')}
                </option>
              ))}
            </select>
            <input
              type="text"
              value={newComponent.subType}
              onChange={(e) => setNewComponent({...newComponent, subType: e.target.value})}
              placeholder="Sub-type (e.g., NPN, electrolytic)"
              className="px-3 py-2 bg-neutral-600 border border-neutral-500 rounded text-neutral-100 placeholder-neutral-400"
            />
            <input
              type="text"
              value={newComponent.commonUse}
              onChange={(e) => setNewComponent({...newComponent, commonUse: e.target.value})}
              placeholder="Common use"
              className="px-3 py-2 bg-neutral-600 border border-neutral-500 rounded text-neutral-100 placeholder-neutral-400"
            />
          </div>
          <textarea
            value={newComponent.description}
            onChange={(e) => setNewComponent({...newComponent, description: e.target.value})}
            placeholder="Description"
            rows={2}
            className="w-full px-3 py-2 bg-neutral-600 border border-neutral-500 rounded text-neutral-100 placeholder-neutral-400 mb-3"
          />
          <textarea
            value={newComponent.testProcedure}
            onChange={(e) => setNewComponent({...newComponent, testProcedure: e.target.value})}
            placeholder="Test procedure"
            rows={2}
            className="w-full px-3 py-2 bg-neutral-600 border border-neutral-500 rounded text-neutral-100 placeholder-neutral-400 mb-4"
          />
          <div className="flex gap-2">
            <button
              onClick={addComponent}
              className="flex items-center gap-2 px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded transition-colors"
            >
              <Save className="h-4 w-4" />
              Save
            </button>
            <button
              onClick={() => setIsAdding(false)}
              className="flex items-center gap-2 px-4 py-2 bg-neutral-600 hover:bg-neutral-700 text-white rounded transition-colors"
            >
              <X className="h-4 w-4" />
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Components List */}
      <div className="space-y-3 max-h-96 overflow-y-auto">
        {components.map(component => (
          <div key={component.id} className="bg-neutral-700 rounded-lg p-4 border border-neutral-600">
            {editingComponent?.id === component.id ? (
              // Edit mode
              <div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-3">
                  <input
                    type="text"
                    value={editingComponent.id}
                    onChange={(e) => setEditingComponent({...editingComponent, id: e.target.value})}
                    className="px-2 py-1 bg-neutral-600 border border-neutral-500 rounded text-neutral-100"
                  />
                  <select
                    value={editingComponent.type}
                    onChange={(e) => setEditingComponent({...editingComponent, type: e.target.value})}
                    className="px-2 py-1 bg-neutral-600 border border-neutral-500 rounded text-neutral-100"
                  >
                    {componentTypes.map(type => (
                      <option key={type} value={type}>
                        {type.replace('_', ' ')}
                      </option>
                    ))}
                  </select>
                </div>
                <textarea
                  value={editingComponent.description}
                  onChange={(e) => setEditingComponent({...editingComponent, description: e.target.value})}
                  className="w-full px-2 py-1 bg-neutral-600 border border-neutral-500 rounded text-neutral-100 mb-2"
                  rows={2}
                />
                <div className="flex gap-2">
                  <button
                    onClick={updateComponent}
                    className="flex items-center gap-1 px-3 py-1 bg-green-600 hover:bg-green-700 text-white text-sm rounded"
                  >
                    <Save className="h-3 w-3" />
                    Save
                  </button>
                  <button
                    onClick={() => setEditingComponent(null)}
                    className="flex items-center gap-1 px-3 py-1 bg-neutral-600 hover:bg-neutral-700 text-white text-sm rounded"
                  >
                    <X className="h-3 w-3" />
                    Cancel
                  </button>
                </div>
              </div>
            ) : (
              // View mode
              <div>
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-1">
                      <h4 className="font-semibold text-neutral-100">{component.id}</h4>
                      <span className="text-sm px-2 py-1 bg-blue-600 text-white rounded">
                        {component.type.replace('_', ' ')}
                      </span>
                      {component.subType && (
                        <span className="text-xs text-neutral-400">
                          {component.subType}
                        </span>
                      )}
                      {component.userDefined && (
                        <span className="text-xs px-2 py-1 bg-purple-600 text-white rounded">
                          Custom
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-neutral-400 mb-2">{component.description}</p>
                    {component.commonUse && (
                      <p className="text-xs text-neutral-500 mb-1">
                        <strong>Use:</strong> {component.commonUse}
                      </p>
                    )}
                    {component.testProcedure && (
                      <p className="text-xs text-neutral-500">
                        <strong>Test:</strong> {component.testProcedure}
                      </p>
                    )}
                  </div>
                  <div className="flex gap-1 ml-4">
                    <button
                      onClick={() => setEditingComponent(component)}
                      className="p-2 text-neutral-400 hover:text-blue-400 hover:bg-neutral-600 rounded"
                    >
                      <Edit className="h-4 w-4" />
                    </button>
                    <button
                      onClick={() => deleteComponent(component.id)}
                      className="p-2 text-neutral-400 hover:text-red-400 hover:bg-neutral-600 rounded"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        ))}
        
        {components.length === 0 && (
          <div className="text-center text-neutral-500 py-8">
            {searchQuery ? 'No components found matching your search' : 'No components in database yet'}
          </div>
        )}
      </div>

      {/* Database Stats */}
      {stats && (
        <div className="mt-6 p-4 bg-neutral-900 rounded-lg border border-neutral-600">
          <h4 className="font-semibold text-neutral-100 mb-2">Database Statistics</h4>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
            <div>
              <div className="text-neutral-400">Total</div>
              <div className="text-neutral-100 font-semibold">{stats.totalComponents}</div>
            </div>
            <div>
              <div className="text-neutral-400">Custom</div>
              <div className="text-purple-400 font-semibold">{stats.userDefined}</div>
            </div>
            <div>
              <div className="text-neutral-400">Verified</div>
              <div className="text-green-400 font-semibold">{stats.verified}</div>
            </div>
            <div>
              <div className="text-neutral-400">Types</div>
              <div className="text-blue-400 font-semibold">{Object.keys(stats.byType).length}</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};