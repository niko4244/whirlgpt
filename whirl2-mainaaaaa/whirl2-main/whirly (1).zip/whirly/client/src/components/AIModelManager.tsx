import React, { useState, useEffect } from 'react';
import { Download, CheckCircle, Clock, Database, Brain, Cpu } from 'lucide-react';

interface AIModel {
  id: string;
  name: string;
  description: string;
  capabilities: string[];
  isInstalled: boolean;
  size: string;
  requirements: string[];
}

export const AIModelManager: React.FC = () => {
  const [models, setModels] = useState<AIModel[]>([]);
  const [loading, setLoading] = useState(true);
  const [installing, setInstalling] = useState<string | null>(null);

  useEffect(() => {
    fetchModels();
  }, []);

  const fetchModels = async () => {
    try {
      const response = await fetch('/api/ai-models');
      const data = await response.json();
      if (data.success) {
        setModels(data.models);
      }
    } catch (error) {
      console.error('Failed to fetch AI models:', error);
    } finally {
      setLoading(false);
    }
  };

  const installModel = async (modelId: string) => {
    setInstalling(modelId);
    try {
      const response = await fetch(`/api/ai-models/${modelId}/install`, {
        method: 'POST'
      });
      const data = await response.json();
      
      if (data.success) {
        // Update the model status
        setModels(prev => prev.map(model => 
          model.id === modelId ? { ...model, isInstalled: true } : model
        ));
      } else {
        console.error('Failed to install model:', data.error);
      }
    } catch (error) {
      console.error('Model installation error:', error);
    } finally {
      setInstalling(null);
    }
  };

  const getCapabilityIcon = (capability: string) => {
    switch (capability) {
      case 'image-analysis':
      case 'component-detection':
      case 'circuit-tracing':
        return <Database className="h-4 w-4" />;
      case 'text-analysis':
      case 'technical-qa':
        return <Brain className="h-4 w-4" />;
      case 'symbol-recognition':
      case 'schematic-parsing':
        return <Cpu className="h-4 w-4" />;
      default:
        return <Database className="h-4 w-4" />;
    }
  };

  const getCapabilityColor = (capability: string) => {
    switch (capability) {
      case 'image-analysis':
      case 'component-detection':
      case 'circuit-tracing':
        return 'bg-blue-600';
      case 'text-analysis':
      case 'technical-qa':
        return 'bg-purple-600';
      case 'symbol-recognition':
      case 'schematic-parsing':
        return 'bg-green-600';
      default:
        return 'bg-gray-600';
    }
  };

  if (loading) {
    return (
      <div className="bg-neutral-800 rounded-xl shadow-lg p-6 border border-neutral-700">
        <div className="animate-pulse">
          <div className="h-6 bg-neutral-700 rounded w-1/3 mb-4"></div>
          <div className="space-y-3">
            {[1, 2, 3].map(i => (
              <div key={i} className="h-20 bg-neutral-700 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-neutral-800 rounded-xl shadow-lg p-6 border border-neutral-700">
      <div className="flex items-center gap-3 mb-6">
        <Brain className="h-6 w-6 text-purple-400" />
        <h3 className="text-xl font-serif-classic font-bold text-neutral-100">
          AI Model Registry
        </h3>
        <span className="text-sm text-neutral-400">
          ({models.filter(m => m.isInstalled).length}/{models.length} installed)
        </span>
      </div>

      <div className="space-y-4">
        {models.map(model => (
          <div key={model.id} className="bg-neutral-700 rounded-lg p-4 border border-neutral-600">
            <div className="flex items-start justify-between mb-3">
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-2">
                  <h4 className="font-semibold text-neutral-100">{model.name}</h4>
                  {model.isInstalled ? (
                    <div className="flex items-center gap-1 text-green-400 text-sm">
                      <CheckCircle className="h-4 w-4" />
                      Installed
                    </div>
                  ) : (
                    <span className="text-neutral-400 text-sm">Available</span>
                  )}
                  <span className="text-neutral-500 text-xs">({model.size})</span>
                </div>
                <p className="text-sm text-neutral-400 mb-3">{model.description}</p>
                
                <div className="flex flex-wrap gap-2 mb-3">
                  {model.capabilities.map(capability => (
                    <div
                      key={capability}
                      className={`flex items-center gap-1 px-2 py-1 rounded text-xs text-white ${getCapabilityColor(capability)}`}
                    >
                      {getCapabilityIcon(capability)}
                      {capability.replace('-', ' ')}
                    </div>
                  ))}
                </div>

                {model.requirements.length > 0 && (
                  <div className="text-xs text-neutral-500">
                    Dependencies: {model.requirements.join(', ')}
                  </div>
                )}
              </div>

              <div className="ml-4">
                {!model.isInstalled && (
                  <button
                    onClick={() => installModel(model.id)}
                    disabled={installing === model.id}
                    className="flex items-center gap-2 px-3 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-neutral-600 text-white text-sm rounded-md transition-colors"
                  >
                    {installing === model.id ? (
                      <>
                        <Clock className="h-4 w-4 animate-spin" />
                        Installing...
                      </>
                    ) : (
                      <>
                        <Download className="h-4 w-4" />
                        Install
                      </>
                    )}
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-6 p-4 bg-neutral-900 rounded-lg border border-neutral-600">
        <h4 className="font-semibold text-neutral-100 mb-2">Dynamic AI Integration</h4>
        <p className="text-sm text-neutral-400 mb-2">
          Whirly automatically discovers and installs AI models based on the tasks you need:
        </p>
        <ul className="text-xs text-neutral-500 space-y-1">
          <li>• Upload circuit diagrams → Circuit analysis models activate</li>
          <li>• Ask technical questions → Text analysis models engage</li>
          <li>• Identify components → Classification models deploy</li>
          <li>• Analyze schematics → Symbol recognition models load</li>
        </ul>
      </div>
    </div>
  );
};