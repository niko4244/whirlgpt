import React, { useState, useEffect } from 'react';
import { UploadCloud, UserCircle as LoaderCircle, Eye, AlertTriangle } from 'lucide-react';
import { CircuitData } from '../types';

interface DiagramViewerProps {
    diagramFile: File | null;
    circuitData: CircuitData | null;
    highlightedElements: string[];
    status: string;
}

export const DiagramViewer: React.FC<DiagramViewerProps> = ({ 
    diagramFile, 
    circuitData, 
    highlightedElements, 
    status 
}) => {
    const [imageUrl, setImageUrl] = useState<string | null>(null);
    const [imageSize, setImageSize] = useState({ width: 0, height: 0 });

    useEffect(() => {
        if (diagramFile) {
            const url = URL.createObjectURL(diagramFile);
            setImageUrl(url);

            // Get image dimensions
            const img = new Image();
            img.onload = () => {
                setImageSize({ width: img.width, height: img.height });
            };
            img.src = url;

            return () => URL.revokeObjectURL(url);
        }
    }, [diagramFile]);

    if (!diagramFile) {
        return (
            <div className="text-center text-neutral-500 font-sans-pro">
                <UploadCloud className="h-16 w-16 mx-auto mb-4" />
                <p>Upload a circuit diagram to begin analysis</p>
                <p className="text-sm mt-2 text-neutral-600">
                    Supports: JPG, PNG, GIF, WebP
                </p>
            </div>
        );
    }

    if (status === 'reconstructing') {
        return (
            <div className="relative w-full h-full">
                {imageUrl && (
                    <img
                        src={imageUrl}
                        alt="Circuit diagram"
                        className="w-full h-full object-contain opacity-30"
                    />
                )}
                <div className="absolute inset-0 flex items-center justify-center bg-black/60">
                    <div className="text-center text-white">
                        <LoaderCircle className="animate-spin h-12 w-12 mx-auto mb-4" />
                        <p className="text-lg font-serif-classic">Analyzing circuit diagram...</p>
                        <div className="text-sm text-neutral-400 mt-3 space-y-1">
                            <p>• Detecting component symbols</p>
                            <p>• Identifying wire connections</p>
                            <p>• Cross-referencing component database</p>
                            <p>• Preparing for online verification</p>
                        </div>
                    </div>
                </div>
            </div>
        );
    }

    const calculateSVGCoordinates = (component: any) => {
        if (!imageSize.width || !imageSize.height) return { x: 0, y: 0 };

        const baseWidth = 700;
        const baseHeight = 450;

        const centerX = (component.box[0] + component.box[2] / 2) / baseWidth * 100;
        const centerY = (component.box[1] + component.box[3] / 2) / baseHeight * 100;

        return { x: `${centerX}%`, y: `${centerY}%` };
    };

    return (
        <div className="relative w-full h-full">
            <img
                src={imageUrl!}
                alt="Circuit diagram"
                className="w-full h-full object-contain"
            />
            {circuitData?.components && (
                <svg
                    className="absolute inset-0 w-full h-full pointer-events-none"
                    viewBox="0 0 100 100"
                    preserveAspectRatio="xMidYMid meet"
                >
                    {circuitData.components.map((component, index) => {
                        const coords = calculateSVGCoordinates(component);
                        const isHighlighted = highlightedElements.includes(component.id);

                        if (!isHighlighted) return null;

                        return (
                            <g key={index}>
                                <circle
                                    cx={coords.x}
                                    cy={coords.y}
                                    r="3"
                                    fill="rgba(244, 162, 97, 0.3)"
                                    stroke="#f4a261"
                                    strokeWidth="0.3"
                                    className="animate-pulse"
                                    vectorEffect="non-scaling-stroke"
                                />

                                <rect
                                    x={`calc(${coords.x} - 4%)`}
                                    y={`calc(${coords.y} - 6%)`}
                                    width="8%"
                                    height="3%"
                                    fill="rgba(244, 162, 97, 0.95)"
                                    rx="0.5"
                                />
                                <text
                                    x={coords.x}
                                    y={`calc(${coords.y} - 4%)`}
                                    fill="white"
                                    fontSize="2"
                                    fontWeight="bold"
                                    textAnchor="middle"
                                    dominantBaseline="middle"
                                >
                                    {component.id}
                                </text>

                                {component.confidence && (
                                    <text
                                        x={coords.x}
                                        y={`calc(${coords.y} + 4%)`}
                                        fill="#f4a261"
                                        fontSize="1.2"
                                        textAnchor="middle"
                                        dominantBaseline="middle"
                                    >
                                        {Math.round(component.confidence * 100)}%
                                    </text>
                                )}
                            </g>
                        );
                    })}
                </svg>
            )}

            {highlightedElements.length > 0 && (
                <div className="absolute top-4 left-1/2 -translate-x-1/2 bg-blue-600 text-white px-4 py-2 rounded-lg text-sm shadow-lg font-sans-pro flex items-center gap-2">
                    <Eye className="h-4 w-4" />
                    Highlighted: {highlightedElements.join(', ')}
                </div>
            )}
            {circuitData?.unknownComponents && circuitData.unknownComponents.length > 0 && (
                <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-orange-600 text-white px-4 py-2 rounded-lg text-sm shadow-lg font-sans-pro flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4" />
                    Needs Research: {circuitData.unknownComponents.join(', ')}
                </div>
            )}
            {circuitData?.analysisMetadata && (
                <div className="absolute top-4 right-4 bg-neutral-800/90 text-white px-3 py-2 rounded text-xs">
                    <div>Components: {circuitData.analysisMetadata.totalComponents}</div>
                    <div>Avg Confidence: {Math.round(circuitData.analysisMetadata.avgConfidence * 100)}%</div>
                </div>
            )}
        </div>
    );
};