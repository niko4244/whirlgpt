import React, { useState, useEffect } from 'react';
import { Key, AlertTriangle, CheckCircle, ExternalLink } from 'lucide-react';

interface ApiKeySetupProps {
  onApiKeySet: (apiKey: string) => void;
  currentApiKey?: string;
}

export const ApiKeySetup: React.FC<ApiKeySetupProps> = ({ onApiKeySet, currentApiKey }) => {
  const [apiKey, setApiKey] = useState(currentApiKey || '');
  const [showSetup, setShowSetup] = useState(!currentApiKey);
  const [isValidating, setIsValidating] = useState(false);
  const [validationStatus, setValidationStatus] = useState<'idle' | 'valid' | 'invalid'>('idle');

  useEffect(() => {
    // Check if API key is stored in localStorage
    const storedKey = localStorage.getItem('whirly_gemini_api_key');
    if (storedKey && !currentApiKey) {
      setApiKey(storedKey);
      onApiKeySet(storedKey);
      setShowSetup(false);
    }
  }, [currentApiKey, onApiKeySet]);

  const handleSaveApiKey = async () => {
    if (!apiKey.trim()) return;

    setIsValidating(true);
    setValidationStatus('idle');

    try {
      // Test the API key with a simple request
      const testResponse = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-exp:generateContent?key=${apiKey}`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            contents: [
              {
                parts: [
                  {
                    text: 'Test connection'
                  }
                ]
              }
            ]
          })
        }
      );

      if (testResponse.ok || testResponse.status === 400) {
        // 400 is expected for this test request, but means API key is valid
        localStorage.setItem('whirly_gemini_api_key', apiKey);
        onApiKeySet(apiKey);
        setValidationStatus('valid');
        setShowSetup(false);
      } else {
        setValidationStatus('invalid');
      }
    } catch (error) {
      console.error('API key validation failed:', error);
      setValidationStatus('invalid');
    } finally {
      setIsValidating(false);
    }
  };

  const handleRemoveApiKey = () => {
    localStorage.removeItem('whirly_gemini_api_key');
    setApiKey('');
    onApiKeySet('');
    setShowSetup(true);
    setValidationStatus('idle');
  };

  if (!showSetup && currentApiKey) {
    return (
      <div className="fixed top-4 right-4 bg-emerald-800 border border-emerald-600 rounded-lg p-3 shadow-lg z-50">
        <div className="flex items-center gap-2 text-emerald-100">
          <CheckCircle className="h-4 w-4" />
          <span className="text-sm">Gemini AI Connected</span>
          <button
            onClick={() => setShowSetup(true)}
            className="text-emerald-300 hover:text-white text-xs underline ml-2"
          >
            Change
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50">
      <div className="bg-neutral-800 rounded-lg p-6 w-full max-w-md mx-4 shadow-xl border border-neutral-700">
        <h3 className="text-xl font-serif-classic font-bold text-neutral-100 mb-4 flex items-center gap-2">
          <Key className="h-5 w-5 text-blue-400" />
          Setup Gemini AI Vision
        </h3>
        
        <div className="mb-4">
          <p className="text-neutral-300 text-sm mb-3">
            To enable real AI-powered circuit analysis, you need a Google Gemini API key.
          </p>
          
          <div className="bg-blue-900/30 border border-blue-600 rounded-lg p-3 mb-4">
            <h4 className="text-blue-300 font-semibold text-sm mb-2">How to get your API key:</h4>
            <ol className="text-blue-200 text-xs space-y-1 list-decimal list-inside">
              <li>Visit Google AI Studio</li>
              <li>Sign in with your Google account</li>
              <li>Create a new API key</li>
              <li>Copy and paste it below</li>
            </ol>
            <a
              href="https://aistudio.google.com/app/apikey"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1 text-blue-300 hover:text-blue-100 text-xs mt-2 underline"
            >
              <ExternalLink className="h-3 w-3" />
              Get API Key
            </a>
          </div>
        </div>

        <div className="mb-4">
          <label className="block text-neutral-300 text-sm font-semibold mb-2">
            Gemini API Key
          </label>
          <input
            type="password"
            value={apiKey}
            onChange={(e) => setApiKey(e.target.value)}
            placeholder="AIza..."
            className="w-full bg-neutral-700 border border-neutral-600 rounded px-3 py-2 text-neutral-200 placeholder-neutral-500"
          />
          
          {validationStatus === 'invalid' && (
            <div className="flex items-center gap-2 mt-2 text-red-400 text-sm">
              <AlertTriangle className="h-4 w-4" />
              Invalid API key. Please check and try again.
            </div>
          )}
          
          {validationStatus === 'valid' && (
            <div className="flex items-center gap-2 mt-2 text-emerald-400 text-sm">
              <CheckCircle className="h-4 w-4" />
              API key validated successfully!
            </div>
          )}
        </div>

        <div className="flex gap-3">
          <button
            onClick={handleSaveApiKey}
            disabled={!apiKey.trim() || isValidating}
            className="flex-1 bg-blue-600 hover:bg-blue-700 disabled:bg-neutral-600 disabled:cursor-not-allowed text-white font-bold py-2 px-4 rounded transition-colors"
          >
            {isValidating ? 'Validating...' : 'Save & Connect'}
          </button>
          
          {currentApiKey && (
            <button
              onClick={handleRemoveApiKey}
              className="px-4 py-2 text-neutral-400 hover:text-white transition-colors"
            >
              Remove
            </button>
          )}
        </div>

        <div className="mt-4 p-3 bg-amber-900/30 border border-amber-600 rounded-lg">
          <div className="flex items-start gap-2">
            <AlertTriangle className="h-4 w-4 text-amber-400 mt-0.5 flex-shrink-0" />
            <div className="text-amber-200 text-xs">
              <p className="font-semibold mb-1">Privacy Notice:</p>
              <p>Your API key is stored locally in your browser and used only for circuit analysis. Images are sent to Google's Gemini API for processing.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};