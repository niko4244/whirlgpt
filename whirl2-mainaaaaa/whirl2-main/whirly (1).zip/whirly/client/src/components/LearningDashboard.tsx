import React from 'react';
import { Brain, TrendingUp, Users, Target, AlertCircle } from 'lucide-react';
import { learningSystem } from '../services/learningSystem';

export const LearningDashboard: React.FC = () => {
  const metrics = learningSystem.getLearningMetrics();
  const trends = learningSystem.getAccuracyTrends();

  return (
    <div className="bg-neutral-800 rounded-xl shadow-lg p-6 border border-neutral-700">
      <h3 className="text-xl font-serif-classic font-bold mb-4 text-neutral-100 flex items-center gap-2">
        <Brain className="h-5 w-5 text-purple-400" />
        AI Learning Progress
      </h3>
      
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <div className="bg-neutral-700 rounded-lg p-3">
          <div className="flex items-center gap-2 mb-1">
            <Users className="h-4 w-4 text-blue-400" />
            <span className="text-xs text-neutral-400">Contributions</span>
          </div>
          <div className="text-lg font-bold text-neutral-100">{trends.totalContributions}</div>
        </div>
        
        <div className="bg-neutral-700 rounded-lg p-3">
          <div className="flex items-center gap-2 mb-1">
            <Target className="h-4 w-4 text-emerald-400" />
            <span className="text-xs text-neutral-400">Feedback</span>
          </div>
          <div className="text-lg font-bold text-neutral-100">{metrics.totalFeedback}</div>
        </div>
        
        <div className="bg-neutral-700 rounded-lg p-3">
          <div className="flex items-center gap-2 mb-1">
            <TrendingUp className="h-4 w-4 text-orange-400" />
            <span className="text-xs text-neutral-400">Accuracy</span>
          </div>
          <div className="text-lg font-bold text-neutral-100">
            {metrics.accuracyImprovement > 0 ? '+' : ''}{metrics.accuracyImprovement.toFixed(1)}%
          </div>
        </div>
        
        <div className="bg-neutral-700 rounded-lg p-3">
          <div className="flex items-center gap-2 mb-1">
            <AlertCircle className="h-4 w-4 text-red-400" />
            <span className="text-xs text-neutral-400">Errors</span>
          </div>
          <div className="text-lg font-bold text-neutral-100">{trends.commonErrors.length}</div>
        </div>
      </div>
      
      {trends.commonErrors.length > 0 && (
        <div>
          <h4 className="text-sm font-semibold text-neutral-300 mb-3">Common Misclassifications</h4>
          <div className="space-y-2">
            {trends.commonErrors.slice(0, 3).map((error, index) => (
              <div key={index} className="bg-neutral-700 rounded p-2">
                <div className="flex justify-between items-center">
                  <span className="text-xs text-neutral-300">{error.error}</span>
                  <span className="text-xs text-orange-400 font-semibold">{error.count}x</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
      
      <div className="mt-4 p-3 bg-purple-900/30 border border-purple-600 rounded-lg">
        <p className="text-purple-200 text-xs">
          <strong>How Learning Works:</strong> When you correct component identifications, 
          the AI learns from your feedback to improve future analysis accuracy. Your contributions 
          help make Whirly smarter for everyone!
        </p>
      </div>
    </div>
  );
};