import React from 'react';
import { Bot, User } from 'lucide-react';
import { ChatMessage as ChatMessageType } from '../types';

interface ChatMessageProps {
    message: ChatMessageType;
}

export const ChatMessage: React.FC<ChatMessageProps> = ({ message }) => {
    const isUser = message.role === 'user';
    
    return (
        <div className={`flex items-start gap-3 my-4 ${isUser ? 'justify-end' : ''}`}>
            {!isUser && (
                <div className="p-2 bg-blue-800 rounded-full flex-shrink-0">
                    <Bot className="h-5 w-5 text-white" />
                </div>
            )}
            <div className={`p-3 rounded-lg max-w-lg shadow-md ${
                isUser ? 'bg-neutral-700 text-neutral-100' : 'bg-neutral-800 text-neutral-100'
            }`}>
                <p className="text-sm font-sans-pro whitespace-pre-wrap">
                    {message.text}
                </p>
                {message.confidence && (
                    <div className="mt-2 text-xs text-neutral-400">
                        Confidence: {Math.round(message.confidence * 100)}%
                    </div>
                )}
            </div>
            {isUser && (
                <div className="p-2 bg-neutral-600 rounded-full flex-shrink-0">
                    <User className="h-5 w-5 text-white" />
                </div>
            )}
        </div>
    );
};