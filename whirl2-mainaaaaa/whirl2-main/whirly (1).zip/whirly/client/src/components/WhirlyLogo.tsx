import React from 'react';

export const WhirlyLogo: React.FC = () => (
    <svg width="48" height="48" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
        <circle cx="50" cy="50" r="45" stroke="#f4a261" strokeWidth="8"/>
        <path d="M50 50 C 65 35, 75 45, 70 60" stroke="#e9c46a" strokeWidth="6" strokeLinecap="round"/>
        <path d="M50 50 C 35 65, 25 55, 30 40" stroke="#e9c46a" strokeWidth="6" strokeLinecap="round"/>
        <circle cx="50" cy="50" r="10" fill="#e76f51"/>
    </svg>
);