import React, { useState, useEffect, useRef } from 'react';
import { UploadCloud, UserCircle as LoaderCircle, Eye, AlertTriangle, Zap, Route } from 'lucide-react';
import { CircuitData } from '../types';

interface VectorDiagramViewerProps {
    diagramFile: File | null;
    circuitData: CircuitData | null;
    highlightedElements: string[];
    highlightedWires: string[];
    status: string;
    onComponentClick?: (componentId: string) => void;
    onWireClick?: (wireId: string) => void;
}

export const VectorDiagramViewer: React.FC<VectorDiagramViewerProps> = ({ 
    diagramFile, 
    circuitData, 
    highlightedElements,
    highlightedWires,
    status,
    onComponentClick,
    onWireClick
}) => {
    const [imageUrl, setImageUrl] = useState<string | null>(null);
    const svgRef = useRef<SVGSVGElement>(null);
    const [hoveredElement, setHoveredElement] = useState<string | null>(null);

    useEffect(() => {
        if (diagramFile) {
            const url = URL.createObjectURL(diagramFile);
            setImageUrl(url);
            return () => URL.revokeObjectURL(url);
        }
    }, [diagramFile]);

    if (!diagramFile) {
        return (
            <div className="text-center text-neutral-500 font-sans-pro">
                <UploadCloud className="h-16 w-16 mx-auto mb-4" />
                <p>Upload a circuit diagram to begin analysis</p>
                <p className="text-sm mt-2 text-neutral-600">
                    Supports: JPG, PNG, GIF, WebP
                </p>
            </div>
        );
    }

    if (status === 'reconstructing') {
        return (
            <div className="relative w-full h-full">
                {imageUrl && (
                    <img
                        src={imageUrl}
                        alt="Circuit diagram"
                        className="w-full h-full object-contain opacity-30"
                    />
                )}
                <div className="absolute inset-0 flex items-center justify-center bg-black/60">
                    <div className="text-center text-white">
                        <LoaderCircle className="animate-spin h-12 w-12 mx-auto mb-4" />
                        <p className="text-lg font-serif-classic">Analyzing circuit with real AI vision...</p>
                        <div className="text-sm text-neutral-400 mt-3 space-y-1">
                            <p>• Detecting component shapes and symbols</p>
                            <p>• Tracing wire connections and paths</p>
                            <p>• Building circuit topology graph</p>
                            <p>• Generating scalable vector representation</p>
                            <p>• Preparing interactive circuit tracer</p>
                        </div>
                    </div>
                </div>
            </div>
        );
    }

    if (!circuitData) {
        return (
            <div className="text-center text-neutral-500 font-sans-pro">
                <AlertTriangle className="h-16 w-16 mx-auto mb-4 text-orange-500" />
                <p>No circuit data available</p>
                <p className="text-sm mt-2 text-neutral-600">
                    Please upload and analyze a circuit diagram
                </p>
            </div>
        );
    }

    const handleElementClick = (elementId: string, elementType: 'component' | 'wire') => {
        if (elementType === 'component' && onComponentClick) {
            onComponentClick(elementId);
        } else if (elementType === 'wire' && onWireClick) {
            onWireClick(elementId);
        }
    };

    return (
        <div className="relative w-full h-full bg-neutral-900 rounded-lg overflow-hidden">
            {/* Background image for reference */}
            {imageUrl && (
                <img
                    src={imageUrl}
                    alt="Circuit diagram"
                    className="absolute inset-0 w-full h-full object-contain opacity-20"
                />
            )}
            
            {/* Vector overlay */}
            <svg
                ref={svgRef}
                className="absolute inset-0 w-full h-full"
                viewBox={circuitData.viewBox}
                preserveAspectRatio="xMidYMid meet"
                style={{ zIndex: 10 }}
            >
                {/* Define gradients and patterns */}
                <defs>
                    <linearGradient id="wireGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                        <stop offset="0%" stopColor="#00ff88" stopOpacity="0.8"/>
                        <stop offset="100%" stopColor="#00cc66" stopOpacity="0.8"/>
                    </linearGradient>
                    <linearGradient id="highlightGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                        <stop offset="0%" stopColor="#ff6b35" stopOpacity="0.9"/>
                        <stop offset="100%" stopColor="#f7931e" stopOpacity="0.9"/>
                    </linearGradient>
                    <filter id="glow">
                        <feGaussianBlur stdDeviation="3" result="coloredBlur"/>
                        <feMerge> 
                            <feMergeNode in="coloredBlur"/>
                            <feMergeNode in="SourceGraphic"/>
                        </feMerge>
                    </filter>
                </defs>

                {/* Render wires */}
                {circuitData.wires.map((wire) => {
                    const isHighlighted = highlightedWires.includes(wire.id);
                    const isHovered = hoveredElement === wire.id;
                    
                    return (
                        <g key={wire.id}>
                            <path
                                d={wire.path}
                                stroke={isHighlighted ? "url(#highlightGradient)" : "url(#wireGradient)"}
                                strokeWidth={isHighlighted ? "4" : isHovered ? "3" : "2"}
                                fill="none"
                                className="cursor-pointer transition-all duration-200"
                                filter={isHighlighted ? "url(#glow)" : undefined}
                                onMouseEnter={() => setHoveredElement(wire.id)}
                                onMouseLeave={() => setHoveredElement(null)}
                                onClick={() => handleElementClick(wire.id, 'wire')}
                            />
                            {/* Wire connection points */}
                            {wire.connectionPoints?.map((point, idx) => (
                                <circle
                                    key={idx}
                                    cx={point[0]}
                                    cy={point[1]}
                                    r={isHighlighted ? "4" : "2"}
                                    fill="#ffff00"
                                    stroke="#ff6600"
                                    strokeWidth="1"
                                    className={isHighlighted ? "animate-pulse" : ""}
                                />
                            ))}
                        </g>
                    );
                })}

                {/* Render components */}
                {circuitData.components.map((component) => {
                    const isHighlighted = highlightedElements.includes(component.id);
                    const isHovered = hoveredElement === component.id;
                    const [x, y, width, height] = component.box;
                    
                    return (
                        <g key={component.id}>
                            {/* Component bounding box */}
                            <rect
                                x={x}
                                y={y}
                                width={width}
                                height={height}
                                fill={isHighlighted ? "rgba(247, 147, 30, 0.3)" : "rgba(0, 255, 136, 0.2)"}
                                stroke={isHighlighted ? "#f7931e" : "#00ff88"}
                                strokeWidth={isHighlighted ? "3" : isHovered ? "2" : "1"}
                                rx="2"
                                className="cursor-pointer transition-all duration-200"
                                filter={isHighlighted ? "url(#glow)" : undefined}
                                onMouseEnter={() => setHoveredElement(component.id)}
                                onMouseLeave={() => setHoveredElement(null)}
                                onClick={() => handleElementClick(component.id, 'component')}
                            />
                            
                            {/* Component label */}
                            <rect
                                x={x + width/2 - 15}
                                y={y - 20}
                                width="30"
                                height="16"
                                fill={isHighlighted ? "#f7931e" : "#00ff88"}
                                rx="8"
                                className={isHighlighted ? "animate-pulse" : ""}
                            />
                            <text
                                x={x + width/2}
                                y={y - 12}
                                textAnchor="middle"
                                dominantBaseline="middle"
                                fill="white"
                                fontSize="10"
                                fontWeight="bold"
                                className="pointer-events-none"
                            >
                                {component.id}
                            </text>
                            
                            {/* Component type label */}
                            <text
                                x={x + width/2}
                                y={y + height/2}
                                textAnchor="middle"
                                dominantBaseline="middle"
                                fill={isHighlighted ? "#f7931e" : "#00ff88"}
                                fontSize="8"
                                className="pointer-events-none"
                            >
                                {component.type}
                            </text>
                            
                            {/* Connection points */}
                            {component.connectionPoints?.map((point, idx) => (
                                <circle
                                    key={idx}
                                    cx={point.x}
                                    cy={point.y}
                                    r={isHighlighted ? "4" : "2"}
                                    fill="#ffff00"
                                    stroke="#ff6600"
                                    strokeWidth="1"
                                    className={isHighlighted ? "animate-pulse" : ""}
                                />
                            ))}
                            
                            {/* Confidence indicator */}
                            {component.confidence && (
                                <text
                                    x={x + width}
                                    y={y}
                                    textAnchor="start"
                                    dominantBaseline="hanging"
                                    fill="#888"
                                    fontSize="8"
                                    className="pointer-events-none"
                                >
                                    {Math.round(component.confidence * 100)}%
                                </text>
                            )}
                        </g>
                    );
                })}
            </svg>

            {/* Status overlays */}
            {highlightedElements.length > 0 && (
                <div className="absolute top-4 left-1/2 -translate-x-1/2 bg-orange-600 text-white px-4 py-2 rounded-lg text-sm shadow-lg font-sans-pro flex items-center gap-2">
                    <Zap className="h-4 w-4" />
                    Components: {highlightedElements.join(', ')}
                </div>
            )}
            
            {highlightedWires.length > 0 && (
                <div className="absolute top-12 left-1/2 -translate-x-1/2 bg-green-600 text-white px-4 py-2 rounded-lg text-sm shadow-lg font-sans-pro flex items-center gap-2">
                    <Route className="h-4 w-4" />
                    Wires: {highlightedWires.join(', ')}
                </div>
            )}
            
            {circuitData?.unknownComponents && circuitData.unknownComponents.length > 0 && (
                <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-orange-600 text-white px-4 py-2 rounded-lg text-sm shadow-lg font-sans-pro flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4" />
                    Needs Research: {circuitData.unknownComponents.join(', ')}
                </div>
            )}
            
            {circuitData?.analysisMetadata && (
                <div className="absolute top-4 right-4 bg-neutral-800/90 text-white px-3 py-2 rounded text-xs">
                    <div>Components: {circuitData.analysisMetadata.totalComponents}</div>
                    <div>Wires: {circuitData.wires.length}</div>
                    <div>Avg Confidence: {Math.round(circuitData.analysisMetadata.avgConfidence * 100)}%</div>
                    <div className="text-green-400">Vector Mode</div>
                </div>
            )}

            {/* Hover tooltip */}
            {hoveredElement && (
                <div className="absolute bottom-4 right-4 bg-neutral-800 text-white px-3 py-2 rounded text-sm shadow-lg">
                    <div className="font-semibold">{hoveredElement}</div>
                    <div className="text-xs text-neutral-400">Click to trace connections</div>
                </div>
            )}
        </div>
    );
};