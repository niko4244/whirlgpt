import React from 'react';
import { Search, CheckCircle, XCircle, UserCircle as LoaderCircle, Wifi } from 'lucide-react';
import { ResearchJob } from '../types';

interface ResearchStatusProps {
    researchJobs: ResearchJob[];
}

export const ResearchStatus: React.FC<ResearchStatusProps> = ({ researchJobs }) => {
    if (researchJobs.length === 0) return null;

    return (
        <div className="fixed top-20 right-4 bg-neutral-800 border border-neutral-700 rounded-lg p-4 max-w-sm shadow-xl z-40">
            <h3 className="text-neutral-100 font-serif-classic font-bold mb-3 flex items-center gap-2">
                <Search className="h-4 w-4 text-orange-400 animate-pulse" />
                AI Research Progress
            </h3>
            <div className="space-y-3 max-h-48 overflow-y-auto">
                {researchJobs.map((job, index) => (
                    <div key={index} className="bg-neutral-700 p-3 rounded text-sm">
                        <div className="flex items-center justify-between mb-2">
                            <span className="font-semibold text-neutral-200">{job.componentId}</span>
                            {job.status === 'completed' ? (
                                <CheckCircle className="h-4 w-4 text-emerald-400" />
                            ) : job.status === 'failed' ? (
                                <XCircle className="h-4 w-4 text-red-400" />
                            ) : (
                                <LoaderCircle className="h-4 w-4 text-orange-400 animate-spin" />
                            )}
                        </div>
                        {job.status === 'researching' && (
                            <div className="text-neutral-400 text-xs mb-2">
                                Searching online databases...
                            </div>
                        )}
                        {job.result && (
                            <div>
                                <div className="font-medium text-neutral-300">{job.result.type}</div>
                                <div className="text-xs text-neutral-500 mt-1 line-clamp-2">
                                    {job.result.description}
                                </div>
                                {job.result.onlineVerification && (
                                    <div className="flex items-center gap-1 mt-2">
                                        <Wifi className="h-3 w-3 text-emerald-400" />
                                        <span className="text-xs text-emerald-400">Verified online</span>
                                    </div>
                                )}
                            </div>
                        )}
                    </div>
                ))}
            </div>
        </div>
    );
};