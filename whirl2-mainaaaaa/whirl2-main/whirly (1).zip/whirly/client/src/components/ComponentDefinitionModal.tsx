import React, { useState } from 'react';
import { AlertTriangle, Search } from 'lucide-react';
import { COMPONENT_DATABASE } from '../data/componentDatabase';

interface ComponentDefinitionModalProps {
    unknownComponents: string[];
    onDefine: (componentId: string, definition: string, componentType: string) => void;
    onClose: () => void;
    onResearch: (componentId: string) => void;
}

export const ComponentDefinitionModal: React.FC<ComponentDefinitionModalProps> = ({ 
    unknownComponents, 
    onDefine, 
    onClose, 
    onResearch 
}) => {
    const [selectedComponentId, setSelectedComponentId] = useState(unknownComponents[0] || '');
    const [definition, setDefinition] = useState('');
    const [componentType, setComponentType] = useState('');

    const componentTypes = Object.keys(COMPONENT_DATABASE).concat(['other']);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (selectedComponentId && definition && componentType) {
            onDefine(selectedComponentId, definition, componentType);
            setDefinition('');
            setComponentType('');
            onClose();
        }
    };

    const handleResearch = () => {
        if (selectedComponentId) {
            onResearch(selectedComponentId);
        }
    };

    return (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50">
            <div className="bg-neutral-800 rounded-lg p-6 w-full max-w-md mx-4 shadow-xl border border-neutral-700">
                <h3 className="text-xl font-serif-classic font-bold text-neutral-100 mb-4 flex items-center gap-2">
                    <AlertTriangle className="h-5 w-5 text-red-500" />
                    Define Unknown Component
                </h3>
                <form onSubmit={handleSubmit}>
                    <div className="mb-4">
                        <label className="block text-neutral-300 text-sm font-semibold mb-2">
                            Component ID
                        </label>
                        <select
                            value={selectedComponentId}
                            onChange={(e) => setSelectedComponentId(e.target.value)}
                            className="w-full bg-neutral-700 border border-neutral-600 rounded px-3 py-2 text-neutral-200"
                            required
                        >
                            {unknownComponents.map(id => (
                                <option key={id} value={id}>{id}</option>
                            ))}
                        </select>
                    </div>

                    <div className="mb-4">
                        <div className="flex items-center gap-2 mb-2">
                            <label className="block text-neutral-300 text-sm font-semibold">
                                Component Type
                            </label>
                            <button
                                type="button"
                                onClick={handleResearch}
                                className="text-xs bg-blue-600 hover:bg-blue-700 text-white px-2 py-1 rounded flex items-center gap-1"
                            >
                                <Search className="h-3 w-3" />
                                Research
                            </button>
                        </div>
                        <select
                            value={componentType}
                            onChange={(e) => setComponentType(e.target.value)}
                            className="w-full bg-neutral-700 border border-neutral-600 rounded px-3 py-2 text-neutral-200"
                            required
                        >
                            <option value="">Select type...</option>
                            {componentTypes.map(type => (
                                <option key={type} value={type}>
                                    {type.charAt(0).toUpperCase() + type.slice(1).replace('_', ' ')}
                                </option>
                            ))}
                        </select>
                    </div>

                    <div className="mb-4">
                        <label className="block text-neutral-300 text-sm font-semibold mb-2">
                            Description
                        </label>
                        <textarea
                            value={definition}
                            onChange={(e) => setDefinition(e.target.value)}
                            className="w-full bg-neutral-700 border border-neutral-600 rounded px-3 py-2 text-neutral-200 h-20 placeholder-neutral-500"
                            placeholder="Describe what this component is and its function..."
                            required
                        />
                    </div>

                    <div className="flex gap-3 mt-6">
                        <button
                            type="submit"
                            className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2 px-4 rounded transition-colors"
                        >
                            Define Component
                        </button>
                        <button
                            type="button"
                            onClick={onClose}
                            className="flex-1 bg-neutral-600 hover:bg-neutral-700 text-white font-bold py-2 px-4 rounded transition-colors"
                        >
                            Cancel
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};