import { CircuitData, ComponentDatabase } from '../types';
import { CircuitTracer } from './circuitTracer';

interface QuestionAnalysisResult {
    response: string;
    elementsToHighlight: string[];
    wiresToHighlight: string[];
}

export const analyzeQuestion = async (
    question: string,
    circuitData: CircuitData,
    knowledgeBase: ComponentDatabase
): Promise<QuestionAnalysisResult> => {
    const currentQuestion = question.toLowerCase();
    let response = '';
    let elementsToHighlight: string[] = [];
    let wiresToHighlight: string[] = [];

    // Initialize circuit tracer for advanced analysis
    const tracer = new CircuitTracer(circuitData);

    // Enhanced question analysis with component highlighting
    if (currentQuestion.includes('signal') || currentQuestion.includes('path') || currentQuestion.includes('trace')) {
        // Use real circuit analysis
        const circuitAnalysis = tracer.analyzeCircuitFunction();
        const criticalPath = tracer.findCriticalPath();
        
        response = `🔀 **Real Signal Path Analysis**\n\n` +
            `Circuit Type: ${circuitAnalysis.circuitType}\n\n` +
            `**Main Signal Path:**\n${criticalPath.description}\n\n` +
            `**Input Components:** ${circuitAnalysis.inputComponents.join(', ') || 'None detected'}\n` +
            `**Output Components:** ${circuitAnalysis.outputComponents.join(', ') || 'None detected'}\n` +
            `**Power Components:** ${circuitAnalysis.powerComponents.join(', ') || 'None detected'}\n\n` +
            `The highlighted path shows the actual traced connections through the circuit.`;
        
        elementsToHighlight = criticalPath.components;
        wiresToHighlight = criticalPath.wires;
    }
    else if (currentQuestion.includes('test') || currentQuestion.includes('troubleshoot') || currentQuestion.includes('measure')) {
        const mentionedComponents = circuitData.components.filter(comp =>
            currentQuestion.includes(comp.id.toLowerCase())
        );

        if (mentionedComponents.length > 0) {
            const comp = mentionedComponents[0];
            const componentInfo = knowledgeBase[comp.type];

            response = `🔧 **Testing ${comp.id} (${comp.type})**\n\n`;

            if (componentInfo?.testKeywords) {
                response += `To test ${comp.id}:\n`;
                componentInfo.testKeywords.forEach(keyword => {
                    response += `• Use a multimeter to check for ${keyword}.\n`;
                });
            } else {
                response += `• Use a multimeter to check for basic continuity.\n`;
            }
            if (comp.estimatedValue) {
                response += `• Expected value: ${comp.estimatedValue}.\n`;
            }
            response += `• Visually inspect for physical damage or discoloration.\n`;
            response += `• Verify proper connections and solder joints.`;
            elementsToHighlight = [comp.id];
            
            // Highlight connected components and wires for testing context
            const neighbors = tracer.getComponentNeighbors(comp.id);
            elementsToHighlight.push(...neighbors.directConnections);
            wiresToHighlight = neighbors.connectedWires;
        } else {
            response = `🔧 **General Testing Procedures**\n\n` +
                `For general troubleshooting, I recommend:\n` +
                `1. Verify power supply voltage at all input points.\n` +
                `2. Check all ground connections for continuity.\n` +
                `3. Perform continuity checks on wires and traces.\n` +
                `4. Systematically test each major component in sequence.\n` +
                `5. If available, use an oscilloscope to trace the signal path.\n\n` +
                `Which specific component would you like to test?`;
        }
    }
    else if (currentQuestion.includes('power') || currentQuestion.includes('supply') || currentQuestion.includes('voltage')) {
        response = `⚡ **Power Supply Analysis**\n\n` +
            `The power supply typically enters the circuit and is filtered by **C1** (Capacitor) to reduce noise and ripple. The **Op-Amp (U1)** and **Transistor (Q1)** will draw power, and their operating points depend on stable voltage.\n\n` +
            `Recommended supply voltage: Usually around 9V-12V DC for this type of op-amp circuit, but always refer to specific component datasheets for exact requirements.`;
        
        // Find actual power-related components
        const circuitAnalysis = tracer.analyzeCircuitFunction();
        elementsToHighlight = circuitAnalysis.powerComponents;
        if (elementsToHighlight.length === 0) {
            // Fallback to common power components
            elementsToHighlight = circuitData.components
                .filter(c => c.type === 'capacitor' || c.type === 'voltage_regulator')
                .map(c => c.id);
        }
    }
    else if (currentQuestion.includes('amplifier') || currentQuestion.includes('gain') || currentQuestion.includes('audio')) {
        const circuitAnalysis = tracer.analyzeCircuitFunction();
        const signalPath = tracer.traceSignalPath(circuitAnalysis.inputComponents[0] || circuitData.components[0]?.id);
        
        response = `🎵 **Real Amplifier Circuit Analysis**\n\n` +
            `Circuit Type: ${circuitAnalysis.circuitType}\n\n` +
            `**Signal Flow:** ${signalPath.description}\n\n` +
            `**Active Components:**\n` +
            circuitData.components
                .filter(c => ['op_amp', 'transistor', 'amplifier'].includes(c.type))
                .map(c => `• **${c.id}** (${c.type}): ${c.estimatedValue}`)
                .join('\n') +
            `\n\n**Supporting Components:**\n` +
            circuitData.components
                .filter(c => ['resistor', 'capacitor'].includes(c.type))
                .map(c => `• **${c.id}** (${c.type}): ${c.estimatedValue}`)
                .join('\n');
        
        elementsToHighlight = signalPath.path;
        wiresToHighlight = signalPath.wires;
    }
    else if (currentQuestion.includes('component') || currentQuestion.includes('what is') || currentQuestion.includes('identify')) {
        const allComponents = circuitData.components.map(comp => {
            const verifiedStatus = comp.verified ? '✓ Verified' : (comp.userDefined ? '📝 User Defined' : '❓ Unverified');
            const confidence = `(${Math.round(comp.confidence * 100)}%)`;
            return `• ${comp.id}: ${comp.type} ${verifiedStatus} ${confidence}${comp.estimatedValue ? ` - ${comp.estimatedValue}` : ''}`;
        }).join('\n');

        response = `🔍 **Component Identification Summary**\n\n${allComponents}\n\n` +
            `${circuitData.unknownComponents.length > 0 ?
                `⚠️ Components still needing research: ${circuitData.unknownComponents.join(', ')}\n` +
                `Use the "Define" button or ask me to research them online.` :
                '✅ All components identified and verified!'
            }`;
        elementsToHighlight = circuitData.components.map(comp => comp.id);
    }
    else {
        // General circuit analysis
        response = `🤖 **Circuit Analysis Assistance**\n\n` +
            `I've analyzed the diagram and identified ${circuitData.components.length} components. ` +
            `How can I help you with this circuit?\n\n` +
            `You can ask me to:\n` +
            `• **Trace the signal path** ("trace signal path")\n` +
            `• **Test a specific component** ("how to test R1")\n` +
            `• **Understand power requirements** ("power supply details")\n` +
            `• **Explain overall function** ("how does this amplifier work")\n` +
            `• **List all identified components** ("list components")\n\n` +
            `What would you like to explore?`;
    }

    return { response, elementsToHighlight, wiresToHighlight };
};

// Export the main function that App.tsx expects
export const processAIQuestion = analyzeQuestion;