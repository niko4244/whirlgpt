import { CircuitData, Component, Wire } from '../types';

export class CircuitTracer {
    private circuitData: CircuitData;
    private connectionGraph: { [key: string]: string[] } = {};

    constructor(circuitData: CircuitData) {
        this.circuitData = circuitData;
        this.buildConnectionGraph();
    }

    private buildConnectionGraph(): void {
        // Initialize graph
        for (const component of this.circuitData.components) {
            this.connectionGraph[component.id] = [];
        }

        // Build connections based on wires
        for (const wire of this.circuitData.wires) {
            const connectedComponents = wire.connectedComponents || [];
            for (let i = 0; i < connectedComponents.length; i++) {
                for (let j = i + 1; j < connectedComponents.length; j++) {
                    const comp1 = connectedComponents[i];
                    const comp2 = connectedComponents[j];
                    if (comp1 && comp2 && comp1 !== comp2) {
                        if (!this.connectionGraph[comp1]?.includes(comp2)) {
                            this.connectionGraph[comp1]?.push(comp2);
                        }
                        if (!this.connectionGraph[comp2]?.includes(comp1)) {
                            this.connectionGraph[comp2]?.push(comp1);
                        }
                    }
                }
            }
        }
    }

    traceSignalPath(fromComponentId: string, toComponentId?: string): {
        path: string[];
        wires: string[];
        description: string;
    } {
        if (!toComponentId) {
            // Return all connections from the component
            const directConnections = this.connectionGraph[fromComponentId] || [];
            const connectedWires = this.findWiresConnectedToComponent(fromComponentId);
            
            return {
                path: [fromComponentId, ...directConnections],
                wires: connectedWires,
                description: `${fromComponentId} is directly connected to: ${directConnections.join(', ') || 'no components'}`
            };
        }

        // Find shortest path between two components
        const path = this.findShortestPath(fromComponentId, toComponentId);
        const wires = this.findWiresInPath(path);
        
        if (path.length === 0) {
            return {
                path: [],
                wires: [],
                description: `No connection found between ${fromComponentId} and ${toComponentId}`
            };
        }

        return {
            path,
            wires,
            description: `Signal path from ${fromComponentId} to ${toComponentId}: ${path.join(' → ')}`
        };
    }

    private findShortestPath(start: string, end: string): string[] {
        if (start === end) return [start];

        const queue: string[][] = [[start]];
        const visited = new Set<string>();

        while (queue.length > 0) {
            const path = queue.shift()!;
            const current = path[path.length - 1];

            if (current === end) {
                return path;
            }

            if (visited.has(current)) continue;
            visited.add(current);

            const neighbors = this.connectionGraph[current] || [];
            for (const neighbor of neighbors) {
                if (!visited.has(neighbor)) {
                    queue.push([...path, neighbor]);
                }
            }
        }

        return []; // No path found
    }

    private findWiresConnectedToComponent(componentId: string): string[] {
        return this.circuitData.wires
            .filter(wire => wire.connectedComponents?.includes(componentId))
            .map(wire => wire.id);
    }

    private findWiresInPath(path: string[]): string[] {
        const wires: string[] = [];
        
        for (let i = 0; i < path.length - 1; i++) {
            const comp1 = path[i];
            const comp2 = path[i + 1];
            
            // Find wire connecting these two components
            const connectingWire = this.circuitData.wires.find(wire => 
                wire.connectedComponents?.includes(comp1) && 
                wire.connectedComponents?.includes(comp2)
            );
            
            if (connectingWire) {
                wires.push(connectingWire.id);
            }
        }
        
        return wires;
    }

    analyzeCircuitFunction(): {
        inputComponents: string[];
        outputComponents: string[];
        powerComponents: string[];
        signalPath: string[];
        circuitType: string;
    } {
        const components = this.circuitData.components;
        
        // Identify different types of components
        const inputComponents = components
            .filter(c => c.type === 'switch' || c.type === 'input')
            .map(c => c.id);
            
        const outputComponents = components
            .filter(c => c.type === 'led' || c.type === 'speaker' || c.type === 'motor')
            .map(c => c.id);
            
        const powerComponents = components
            .filter(c => c.type === 'voltage_regulator' || c.type === 'battery')
            .map(c => c.id);

        // Determine circuit type based on components
        let circuitType = 'unknown';
        if (components.some(c => c.type === 'op_amp')) {
            circuitType = 'amplifier';
        } else if (components.some(c => c.type === 'transistor')) {
            circuitType = 'switching/amplifier';
        } else if (components.some(c => c.type === 'diode')) {
            circuitType = 'rectifier/protection';
        }

        // Try to trace main signal path
        let signalPath: string[] = [];
        if (inputComponents.length > 0 && outputComponents.length > 0) {
            const pathResult = this.traceSignalPath(inputComponents[0], outputComponents[0]);
            signalPath = pathResult.path;
        }

        return {
            inputComponents,
            outputComponents,
            powerComponents,
            signalPath,
            circuitType
        };
    }

    getComponentNeighbors(componentId: string): {
        directConnections: string[];
        connectedWires: string[];
        connectionCount: number;
    } {
        const directConnections = this.connectionGraph[componentId] || [];
        const connectedWires = this.findWiresConnectedToComponent(componentId);
        
        return {
            directConnections,
            connectedWires,
            connectionCount: directConnections.length
        };
    }

    findCriticalPath(): {
        components: string[];
        wires: string[];
        description: string;
    } {
        // Find the longest path in the circuit (main signal chain)
        let longestPath: string[] = [];
        
        for (const startComponent of this.circuitData.components) {
            for (const endComponent of this.circuitData.components) {
                if (startComponent.id !== endComponent.id) {
                    const path = this.findShortestPath(startComponent.id, endComponent.id);
                    if (path.length > longestPath.length) {
                        longestPath = path;
                    }
                }
            }
        }
        
        const wires = this.findWiresInPath(longestPath);
        
        return {
            components: longestPath,
            wires,
            description: `Critical signal path: ${longestPath.join(' → ')}`
        };
    }

    validateCircuitIntegrity(): {
        isValid: boolean;
        issues: string[];
        isolatedComponents: string[];
    } {
        const issues: string[] = [];
        const isolatedComponents: string[] = [];
        
        // Check for isolated components
        for (const component of this.circuitData.components) {
            const connections = this.connectionGraph[component.id] || [];
            if (connections.length === 0) {
                isolatedComponents.push(component.id);
                issues.push(`${component.id} has no connections`);
            }
        }
        
        // Check for components with only one connection (might be incomplete)
        for (const component of this.circuitData.components) {
            const connections = this.connectionGraph[component.id] || [];
            if (connections.length === 1 && component.type !== 'led' && component.type !== 'switch') {
                issues.push(`${component.id} has only one connection (might be incomplete)`);
            }
        }
        
        return {
            isValid: issues.length === 0,
            issues,
            isolatedComponents
        };
    }
}