# Whirly Circuit Analysis AI - Project Overview

## Project Description
Whirly is an advanced AI-powered circuit analysis application that can analyze electronic circuit diagrams, identify components, trace connections, and provide intelligent assistance for electronics engineers and hobbyists.

## Recent Changes (December 2024)
- **Migration from Bolt to Replit**: Successfully migrated and adapted all code for Replit environment
- **Built-in AI Analysis**: Replaced heavy model downloads with specialized built-in algorithms
- **Auto-Configuration System**: Models configure automatically without user prompts or downloads
- **Persistent Component Database**: JSON-based database for user-defined component knowledge
- **Removed External Dependencies**: No API keys or disk-heavy models needed
- **Enhanced Circuit Analysis**: Advanced pattern recognition and topology analysis algorithms

## Architecture

### Backend (Node.js/Express)
- **Server**: Express server running on port 5000 with Vite integration
- **AI Services**: 
  - Circuit Analysis Engine with specialized pattern recognition
  - Dynamic AI model registry for automatic configuration
  - Built-in algorithms for component detection and connection tracing
  - Persistent component database service
- **API Routes**: Circuit analysis, component research, and model management endpoints
- **Storage**: In-memory storage for development (easily upgradeable to PostgreSQL)

### Frontend (React/TypeScript)
- **Main App**: Circuit diagram upload and analysis interface
- **Components**: Modular React components for different UI sections
- **AI Integration**: Direct communication with local AI services
- **Real-time Updates**: Live analysis and interactive circuit visualization

### AI Model System
- **Dynamic Discovery**: Automatically finds appropriate AI models for different tasks
- **Capability Mapping**: Maps tasks to required AI capabilities
- **Auto-Installation**: Downloads and configures models as needed
- **Fallback Analysis**: Sophisticated fallback when models aren't available

## Key Features
1. **Circuit Image Analysis**: Upload circuit diagrams for automatic component detection
2. **Component Identification**: AI-powered identification of electronic components
3. **Connection Tracing**: Automatic wire and connection mapping
4. **Technical Q&A**: Ask questions about circuits and get expert-level answers
5. **Component Research**: Detailed component information and testing procedures
6. **Interactive Visualization**: Click-to-highlight components and connections
7. **Learning System**: Continuous improvement through user feedback

## AI Analysis Capabilities
- **Circuit Analysis Engine**: Built-in pattern recognition for component detection (0MB)
- **Component Classifier**: Advanced classification algorithms (auto-configured)
- **Technical Knowledge Base**: Persistent component database with user teaching
- **Connection Tracer**: Graph theory-based topology analysis (built-in)
- **Schematic Reader**: Symbol recognition algorithms (lightweight)
- **Auto-Growing Database**: Learns from user input without prompts

## User Preferences
- **Auto-Install**: System should automatically install needed addons without asking
- **Non-Intrusive UI**: No full-screen overlays that can't be hidden
- **Built-in Processing**: Use lightweight algorithms instead of heavy model downloads
- **Database Growth**: Whirly has permission to grow and improve automatically
- **Communication Style**: Technical but accessible, no emojis

## Technical Stack
- **Frontend**: React, TypeScript, Tailwind CSS, Vite
- **Backend**: Node.js, Express, TypeScript
- **AI/ML**: Python, Transformers, PyTorch, Hugging Face models
- **Database**: In-memory (development), PostgreSQL (production ready)
- **Build System**: Vite with hot module replacement
- **Package Management**: npm

## Development Guidelines
- Follow fullstack_js blueprint patterns
- Minimize external dependencies
- Use TypeScript for type safety
- Implement proper error handling
- Maintain security best practices
- Document AI model integrations

## Deployment
- **Platform**: Replit Deployments
- **Port**: 5000 (serves both API and frontend)
- **Environment**: Production-ready with automatic TLS and health checks
- **Domain**: Available under .replit.app or custom domain

## Security Features
- Client/server separation
- No sensitive data exposure
- Local AI processing (no data leaves the system)
- Secure file upload handling
- Input validation and sanitization

## Project Status
- ✅ Migration completed successfully
- ✅ Built-in AI analysis functional
- ✅ Auto-configuration system working
- ✅ Persistent database operational
- ✅ Non-intrusive UI implemented
- ✅ Ready for deployment
- 📈 Auto-learning database growing with usage